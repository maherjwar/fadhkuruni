package com.example.fadhkuruni

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.icu.text.SimpleDateFormat as IcuDateFormat
import android.icu.util.Calendar as IcuCalendar
import android.icu.util.ULocale
import android.location.Location
import android.location.LocationManager
import java.util.Date
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

private const val DAY_MS = 86_400_000L
private val HIJRI_LOCALE = ULocale("ar@calendar=islamic-umalqura")

/** ضبط التاريخ الهجري بالأيام، في حال اختلاف التقويم عن الرسمي. */
object HijriPrefs {
    private const val PREFS = "settings"
    private const val KEY = "hijri_offset"

    fun offset(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY, 0)

    fun setOffset(context: Context, value: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(KEY, value.coerceIn(-2, 2)).apply()
    }
}

/** الآن مع تعديل التاريخ الهجري. */
fun hijriNow(context: Context): Date =
    Date(System.currentTimeMillis() + HijriPrefs.offset(context) * DAY_MS)

fun hijriFormat(date: Date, pattern: String): String =
    IcuDateFormat(pattern, HIJRI_LOCALE).format(date)

fun hijriDate(context: Context): String = try {
    hijriFormat(hijriNow(context), "EEEE d MMMM yyyy") + " هـ"
} catch (e: Exception) {
    ""
}

fun hijriOffsetLabel(offset: Int): String = when {
    offset == 0 -> "بدون تعديل"
    offset > 0 -> "+${arabicNumber(offset)} يوم"
    else -> "−${arabicNumber(-offset)} يوم"
}

data class Occasion(val name: String, val hijriMonth: Int, val hijriDay: Int, val lastDay: Int = hijriDay)

class UpcomingOccasion(val occasion: Occasion, val date: Date, val daysLeft: Int)

/** المناسبات المعتمدة عند أهل الأثر، بحسب ما يذكره تطبيق المساجد. */
val OCCASIONS = listOf(
    Occasion("رمضان", 9, 1),
    Occasion("العشر الأواخر", 9, 20),
    Occasion("عيد الفطر", 10, 1),
    Occasion("غرة ذي الحجة", 12, 1),
    Occasion("الحج", 12, 8, 12),
    Occasion("يوم عرفة", 12, 9),
    Occasion("عيد الأضحى", 12, 10),
    Occasion("أيام التشريق", 12, 11, 13),
    Occasion("رأس السنة الهجرية", 1, 1),
)

/** المناسبات القادمة مرتبة حسب الأقرب. */
fun upcomingOccasions(context: Context): List<UpcomingOccasion> {
    val offset = HijriPrefs.offset(context)
    val hijriYear = IcuCalendar.getInstance(HIJRI_LOCALE).apply { time = hijriNow(context) }
        .get(IcuCalendar.YEAR)
    val today = startOfToday()
    return OCCASIONS.map { o ->
        var date = gregorianOf(hijriYear, o.hijriMonth, o.hijriDay, offset)
        if (date.before(today)) date = gregorianOf(hijriYear + 1, o.hijriMonth, o.hijriDay, offset)
        UpcomingOccasion(o, date, daysBetween(today, date))
    }.sortedBy { it.daysLeft }
}

private fun gregorianOf(year: Int, month: Int, day: Int, offsetDays: Int): Date {
    val c = IcuCalendar.getInstance(HIJRI_LOCALE)
    c.clear()
    c.set(IcuCalendar.YEAR, year)
    c.set(IcuCalendar.MONTH, month - 1)
    c.set(IcuCalendar.DAY_OF_MONTH, day)
    return Date(c.timeInMillis - offsetDays * DAY_MS)
}

private fun startOfToday(): Date {
    val c = java.util.Calendar.getInstance()
    c.set(java.util.Calendar.HOUR_OF_DAY, 0)
    c.set(java.util.Calendar.MINUTE, 0)
    c.set(java.util.Calendar.SECOND, 0)
    c.set(java.util.Calendar.MILLISECOND, 0)
    return c.time
}

private fun daysBetween(from: Date, to: Date): Int =
    Math.round((to.time - from.time).toDouble() / DAY_MS).toInt()

/** اتجاه القبلة من الموقع الأخير المعروف. */
object Qibla {
    private const val KAABA_LAT = 21.4225
    private const val KAABA_LNG = 39.8262

    fun bearing(lat: Double, lng: Double): Double {
        val phi1 = Math.toRadians(lat)
        val phi2 = Math.toRadians(KAABA_LAT)
        val dLambda = Math.toRadians(KAABA_LNG - lng)
        val y = sin(dLambda) * cos(phi2)
        val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(dLambda)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    @SuppressLint("MissingPermission")
    fun lastLocation(context: Context): Location? {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER,
        )
            .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
            .maxByOrNull { it.time }
    }
}

fun hasLocationPermission(context: Context): Boolean =
    context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED

private val HIJRI_MONTH_NAMES = listOf(
    "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
    "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة",
)

/** نص التاريخ الهجري للمناسبة، مثل: ٨–١٢ ذو الحجة ١٤٤٨ هـ. */
fun occasionHijriLabel(up: UpcomingOccasion): String {
    val year = IcuCalendar.getInstance(HIJRI_LOCALE).apply { time = up.date }.get(IcuCalendar.YEAR)
    val o = up.occasion
    val days = if (o.lastDay == o.hijriDay) arabicNumber(o.hijriDay)
    else "${arabicNumber(o.hijriDay)}–${arabicNumber(o.lastDay)}"
    return "$days ${HIJRI_MONTH_NAMES[o.hijriMonth - 1]} ${arabicNumber(year)} هـ"
}

/** التاريخ الميلادي للمناسبة مع اليوم. */
fun occasionGregorianLabel(date: Date): String =
    java.text.SimpleDateFormat("EEEE، d MMMM yyyy", java.util.Locale.forLanguageTag("ar")).format(date)

/** بيانات شهر هجري مُزاحاً بعدد من الأشهر: 0 للحالي، والسالب للماضي. */
class HijriMonthInfo(val title: String, val days: Int, val firstWeekday: Int, val today: Int)

fun hijriMonthInfo(context: Context, shift: Int): HijriMonthInfo {
    val base = IcuCalendar.getInstance(HIJRI_LOCALE).apply { time = hijriNow(context) }
    val today = base.get(IcuCalendar.DAY_OF_MONTH)
    val cal = base.clone() as IcuCalendar
    cal.set(IcuCalendar.DAY_OF_MONTH, 1)
    cal.add(IcuCalendar.MONTH, shift)
    val title = hijriFormat(cal.time, "MMMM yyyy")
    val days = cal.getActualMaximum(IcuCalendar.DAY_OF_MONTH)
    val firstWeekday = cal.get(IcuCalendar.DAY_OF_WEEK) - IcuCalendar.SUNDAY
    return HijriMonthInfo(title, days, firstWeekday, if (shift == 0) today else -1)
}
