package com.example.fadhkuruni

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

/** أنواع التذكير الثلاثة. */
enum class ReminderKind(val title: String, val defHour: Int, val defMinute: Int) {
    MORNING("أذكار الصباح", 6, 30),
    EVENING("أذكار المساء", 17, 30),
    SLEEP("أذكار النوم", 21, 30),
}

/** إعداد تذكير واحد: مفعّل أم لا، والوقت. */
data class ReminderConfig(
    val kind: ReminderKind,
    val enabled: Boolean,
    val hour: Int,
    val minute: Int,
)

object Reminders {
    private const val PREFS = "settings"
    private const val CHANNEL_ID = "adhkar_reminders"
    private const val EXTRA_KIND = "kind"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context): List<ReminderConfig> {
        val p = prefs(context)
        return ReminderKind.entries.map { k ->
            ReminderConfig(
                kind = k,
                enabled = p.getBoolean("${k.name}_enabled", false),
                hour = p.getInt("${k.name}_hour", k.defHour),
                minute = p.getInt("${k.name}_minute", k.defMinute),
            )
        }
    }

    /** يحفظ الإعداد ويعيد جدولة تذكيره فوراً. */
    fun save(context: Context, config: ReminderConfig) {
        prefs(context).edit()
            .putBoolean("${config.kind.name}_enabled", config.enabled)
            .putInt("${config.kind.name}_hour", config.hour)
            .putInt("${config.kind.name}_minute", config.minute)
            .apply()
        reschedule(context, config)
    }

    /** يُعيد جدولة كل التذكيرات (تُستخدم بعد إعادة تشغيل الجهاز). */
    fun rescheduleAll(context: Context) {
        load(context).forEach { reschedule(context, it) }
    }

    private fun reschedule(context: Context, config: ReminderConfig) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = pendingIntent(context, config.kind)
        if (!config.enabled) {
            am.cancel(intent)
            return
        }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, config.hour)
            set(Calendar.MINUTE, config.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            cal.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            intent,
        )
    }

    private fun pendingIntent(context: Context, kind: ReminderKind): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
            .putExtra(EXTRA_KIND, kind.name)
        return PendingIntent.getBroadcast(
            context,
            100 + kind.ordinal,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    fun showNotification(context: Context, kind: ReminderKind) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "تذكير الأذكار", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(kind.title)
            .setContentText("حان وقت ${kind.title}")
            .setAutoCancel(true)
            .build()
        nm.notify(kind.ordinal, notification)
    }

    /** يُستدعى من ReminderReceiver عند وصول المنبّه. */
    fun handleAlarm(context: Context, intent: Intent) {
        val name = intent.getStringExtra(EXTRA_KIND) ?: return
        val kind = runCatching { ReminderKind.valueOf(name) }.getOrNull() ?: return
        showNotification(context, kind)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminders.handleAlarm(context, intent)
    }
}

/** المنبّهات تُمسح عند إعادة تشغيل الجهاز، فنعيد جدولتها هنا. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Reminders.rescheduleAll(context)
        }
    }
}
