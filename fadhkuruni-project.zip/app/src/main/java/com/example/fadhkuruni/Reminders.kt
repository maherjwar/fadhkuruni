package com.example.fadhkuruni

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

/** أنواع التذكير الثلاثة. */
enum class ReminderKind(val title: String, val defHour: Int, val defMinute: Int) {
    MORNING("أذكار الصباح", 6, 30),
    EVENING("أذكار المساء", 17, 30),
    SLEEP("أذكار النوم", 21, 30),
}

/** إعداد تذكير واحد: مفعّل أم لا، والوقت. */
data class ReminderConfig(
    val kind: ReminderKind,
    val enabled: Boolean,
    val hour: Int,
    val minute: Int,
)

object Reminders {
    private const val PREFS = "settings"
    private const val CHANNEL_ID = "adhkar_reminders"
    private const val EXTRA_KIND = "kind"
    private const val EXTRA_FOLLOWUP = "followup"
    private const val KEY_FOLLOWUP = "followup_enabled"
    private const val FOLLOWUP_CODE = 200
    private const val FOLLOWUP_NOTIFICATION_ID = 50
    private const val FOLLOWUP_DELAY_MS = 90L * 60L * 1000L
    private const val MORNING_CHAPTER_ID = 27

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun alarmManager(context: Context) =
        context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun load(context: Context): List<ReminderConfig> {
        val p = prefs(context)
        return ReminderKind.entries.map { k ->
            ReminderConfig(
                kind = k,
                enabled = p.getBoolean("${k.name}_enabled", false),
                hour = p.getInt("${k.name}_hour", k.defHour),
                minute = p.getInt("${k.name}_minute", k.defMinute),
            )
        }
    }

    /** يحفظ الإعداد ويعيد جدولة تذكيره فوراً. */
    fun save(context: Context, config: ReminderConfig) {
        prefs(context).edit()
            .putBoolean("${config.kind.name}_enabled", config.enabled)
            .putInt("${config.kind.name}_hour", config.hour)
            .putInt("${config.kind.name}_minute", config.minute)
            .apply()
        reschedule(context, config)
    }

    /** هل إذن الإشعارات ممنوح (يُعدّ ممنوحاً قبل أندرويد 13). */
    fun hasNotificationPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun isFollowUpEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_FOLLOWUP, true)

    fun setFollowUpEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_FOLLOWUP, enabled).apply()
        if (!enabled) alarmManager(context).cancel(followUpPendingIntent(context))
    }

    /** يُعيد جدولة كل التذكيرات (تُستخدم بعد إعادة تشغيل الجهاز). */
    fun rescheduleAll(context: Context) {
        load(context).forEach { reschedule(context, it) }
    }

    private fun reschedule(context: Context, config: ReminderConfig) {
        val am = alarmManager(context)
        val intent = pendingIntent(context, config.kind)
        if (!config.enabled) {
            am.cancel(intent)
            return
        }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, config.hour)
            set(Calendar.MINUTE, config.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            cal.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            intent,
        )
    }

    private fun pendingIntent(context: Context, kind: ReminderKind): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
            .putExtra(EXTRA_KIND, kind.name)
        return PendingIntent.getBroadcast(
            context,
            100 + kind.ordinal,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun followUpPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
            .putExtra(EXTRA_FOLLOWUP, true)
        return PendingIntent.getBroadcast(
            context,
            FOLLOWUP_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    /** تذكير متابعة واحد بعد ساعة ونصف من تذكير الصباح. */
    private fun scheduleFollowUp(context: Context) {
        alarmManager(context).set(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + FOLLOWUP_DELAY_MS,
            followUpPendingIntent(context),
        )
    }

    private fun contentIntent(context: Context): PendingIntent =
        PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun postNotification(context: Context, id: Int, title: String, text: String) {
        if (!hasNotificationPermission(context)) return

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "تذكير الأذكار", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(contentIntent(context))
            .setAutoCancel(true)
            .build()
        nm.notify(id, notification)
    }

    /** يُستدعى من ReminderReceiver عند وصول المنبّه. */
    fun handleAlarm(context: Context, intent: Intent) {
        if (intent.getBooleanExtra(EXTRA_FOLLOWUP, false)) {
            val morning = HISN_CHAPTERS.first { it.id == MORNING_CHAPTER_ID }
            val counts = CounterStore.load(context, CounterStore.today())
            if (!CounterStore.isChapterComplete(counts, morning)) {
                postNotification(
                    context,
                    FOLLOWUP_NOTIFICATION_ID,
                    "متابعة أذكار الصباح",
                    "لم تكتمل أذكار الصباح والمساء بعد",
                )
            }
            return
        }
        val name = intent.getStringExtra(EXTRA_KIND) ?: return
        val kind = runCatching { ReminderKind.valueOf(name) }.getOrNull() ?: return
        postNotification(context, kind.ordinal, kind.title, "حان وقت ${kind.title}")
        if (kind == ReminderKind.MORNING && isFollowUpEnabled(context)) scheduleFollowUp(context)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminders.handleAlarm(context, intent)
    }
}

/** المنبّهات تُمسح عند إعادة تشغيل الجهاز، فنعيد جدولتها هنا. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Reminders.rescheduleAll(context)
        }
    }
}
