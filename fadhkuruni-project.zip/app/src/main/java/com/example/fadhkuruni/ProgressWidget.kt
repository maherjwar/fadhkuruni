package com.example.fadhkuruni

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** عنصر على الشاشة الرئيسية يعرض تقدم أذكار اليوم. */
class ProgressWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        val counts = CounterStore.load(context, CounterStore.today())
        val morning = HISN_CHAPTERS.first { it.id == 27 }
        val morningDone = CounterStore.isChapterComplete(counts, morning)
        val totalItems = HISN_CHAPTERS.sumOf { it.items.size }
        val doneItems = HISN_CHAPTERS.sumOf { ch ->
            ch.items.indices.count { i -> (counts[CounterStore.key(ch, i)] ?: 0) >= ch.items[i].repeat }
        }

        val views = RemoteViews(context.packageName, R.layout.widget_progress)
        views.setTextViewText(R.id.widget_daily,
            if (morningDone) "أذكار الصباح والمساء: تمت ✓" else "أذكار الصباح والمساء: لم تكتمل")
        views.setTextViewText(R.id.widget_count,
            "${arabicNumber(doneItems)} من ${arabicNumber(totalItems)} ذكراً اليوم")
        val launch = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        views.setOnClickPendingIntent(R.id.widget_root, launch)
        for (id in appWidgetIds) manager.updateAppWidget(id, views)
    }

    companion object {
        /** يحدّث كل نسخ العنصر الموضوعة على الشاشة. */
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ProgressWidget::class.java))
            if (ids.isNotEmpty()) ProgressWidget().onUpdate(context, manager, ids)
        }
    }
}
