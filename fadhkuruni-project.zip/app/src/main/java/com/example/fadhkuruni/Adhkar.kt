package com.example.fadhkuruni

/** نص الذكر وعدد التكرار المطلوب. */
data class Dhikr(
    val text: String,
    val repeat: Int = 1,
)

/** باب من حصن المسلم. */
data class Chapter(
    val id: Int,
    val title: String,
    val items: List<Dhikr>,
)
