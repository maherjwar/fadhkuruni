package com.example.fadhkuruni

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** عدادات الأذكار لكل يوم. المفتاح المحفوظ: "yyyy-MM-dd|c<رقم الباب>-<رقم الذكر>". */
object CounterStore {
    private const val PREFS = "adhkar_counts"
    private const val SEP = "|"
    private const val DAILY_CHAPTER_ID = 27
    private const val DAY_MS = 86_400_000L
    private val dayFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val dailyChapter: Chapter
        get() = HISN_CHAPTERS.first { it.id == DAILY_CHAPTER_ID }

    fun key(chapter: Chapter, index: Int): String = "c${chapter.id}-$index"

    fun dayKey(cal: Calendar): String = dayFormat.format(cal.time)

    fun today(): String = dayKey(Calendar.getInstance())

    fun dayCalendar(day: String): Calendar = Calendar.getInstance().apply {
        time = dayFormat.parse(day) ?: Date()
    }

    fun load(context: Context, day: String): Map<String, Int> {
        val prefix = day + SEP
        val result = mutableMapOf<String, Int>()
        for ((k, v) in prefs(context).all) {
            if (k.startsWith(prefix) && v is Int) result[k.removePrefix(prefix)] = v
        }
        return result
    }

    fun save(context: Context, day: String, key: String, value: Int) {
        prefs(context).edit().putInt(day + SEP + key, value).apply()
    }

    fun resetDay(context: Context, day: String) {
        val prefix = day + SEP
        val p = prefs(context)
        val editor = p.edit()
        p.all.keys.filter { it.startsWith(prefix) }.forEach { editor.remove(it) }
        editor.apply()
    }

    fun isChapterComplete(counts: Map<String, Int>, chapter: Chapter): Boolean =
        chapter.items.indices.all { i -> (counts[key(chapter, i)] ?: 0) >= chapter.items[i].repeat }

    /** يوم مكتمل = باب أذكار الصباح والمساء مكتمل. */
    fun isDayComplete(context: Context, day: String): Boolean =
        isChapterComplete(load(context, day), dailyChapter)

    /** كل الأيام التي يكون فيها باب الصباح والمساء مكتملاً. */
    fun completedDays(context: Context): Set<String> {
        val byDay = HashMap<String, MutableMap<String, Int>>()
        for ((k, v) in prefs(context).all) {
            val i = k.indexOf(SEP)
            if (i <= 0 || v !is Int) continue
            byDay.getOrPut(k.substring(0, i)) { HashMap() }[k.substring(i + 1)] = v
        }
        return byDay.filterValues { isChapterComplete(it, dailyChapter) }.keys
    }

    /** عدد الأيام المتتالية المكتملة، ويبدأ من اليوم (أو الأمس إن لم يكتمل اليوم بعد). */
    fun streak(context: Context): Int {
        val cal = Calendar.getInstance()
        if (!isDayComplete(context, dayKey(cal))) cal.add(Calendar.DAY_OF_YEAR, -1)
        var count = 0
        while (count < 3650 && isDayComplete(context, dayKey(cal))) {
            count++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return count
    }

    private fun epochDay(day: String): Long {
        val date = dayFormat.parse(day) ?: return 0L
        return (date.time + TimeZone.getDefault().getOffset(date.time)) / DAY_MS
    }

    /** أطول سلسلة متتالية من الأيام المكتملة في كل السجل. */
    fun longestStreak(context: Context): Int {
        val epochs = completedDays(context).map { epochDay(it) }.sorted()
        var best = 0
        var run = 0
        var prev = Long.MIN_VALUE
        for (e in epochs) {
            run = if (e == prev + 1) run + 1 else 1
            best = maxOf(best, run)
            prev = e
        }
        return best
    }

    fun completedThisMonth(context: Context): Int {
        val prefix = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
        return completedDays(context).count { it.startsWith(prefix) }
    }

    /** تصدير كل العدادات إلى JSON. */
    fun exportJson(context: Context): String {
        val obj = JSONObject()
        for ((k, v) in prefs(context).all) {
            if (v is Int) obj.put(k, v)
        }
        return obj.toString(2)
    }

    /** استعادة العدادات من JSON، وتعيد عدد العدادات المستوردة. */
    fun importJson(context: Context, json: String): Int {
        val obj = JSONObject(json)
        val editor = prefs(context).edit()
        var count = 0
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k: String = keys.next()
            val v = obj.optInt(k, -1)
            if (v >= 0 && k.contains(SEP)) {
                editor.putInt(k, v)
                count++
            }
        }
        editor.apply()
        return count
    }
}

/** إعدادات العرض. */
object DisplayPrefs {
    private const val PREFS = "settings"
    private const val KEY_FONT = "font_size"
    private const val KEY_FONT_CHOICE = "font_choice"
    const val DEFAULT_FONT = 21f

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun fontSize(context: Context): Float = prefs(context).getFloat(KEY_FONT, DEFAULT_FONT)

    fun setFontSize(context: Context, size: Float) {
        prefs(context).edit().putFloat(KEY_FONT, size).apply()
    }

    fun fontChoice(context: Context): Int = prefs(context).getInt(KEY_FONT_CHOICE, 0)

    fun setFontChoice(context: Context, choice: Int) {
        prefs(context).edit().putInt(KEY_FONT_CHOICE, choice).apply()
    }
}

/** حالة التطبيق: آخر باب مفتوح والعداد الحر. */
object AppState {
    private const val PREFS = "app_state"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun lastChapterId(context: Context): Int? =
        prefs(context).getInt("last_chapter", 0).takeIf { it > 0 }

    fun setLastChapterId(context: Context, id: Int) {
        prefs(context).edit().putInt("last_chapter", id).apply()
    }

    fun freeCounter(context: Context): Int = prefs(context).getInt("free_counter", 0)

    fun setFreeCounter(context: Context, value: Int) {
        prefs(context).edit().putInt("free_counter", value).apply()
    }
}

