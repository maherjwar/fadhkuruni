package com.example.fadhkuruni

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** عدادات الأذكار لكل يوم. المفتاح المحفوظ: "yyyy-MM-dd|الفئة-الرقم". */
object CounterStore {
    private const val PREFS = "adhkar_counts"
    private const val SEP = "|"
    private val dayFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun dayKey(cal: Calendar): String = dayFormat.format(cal.time)

    fun today(): String = dayKey(Calendar.getInstance())

    fun load(context: Context, day: String): Map<String, Int> {
        val prefix = day + SEP
        val result = mutableMapOf<String, Int>()
        for ((k, v) in prefs(context).all) {
            if (k.startsWith(prefix) && v is Int) result[k.removePrefix(prefix)] = v
        }
        return result
    }

    fun save(context: Context, day: String, key: String, value: Int) {
        prefs(context).edit().putInt(day + SEP + key, value).apply()
    }

    fun resetDay(context: Context, day: String) {
        val prefix = day + SEP
        val p = prefs(context)
        val editor = p.edit()
        p.all.keys.filter { it.startsWith(prefix) }.forEach { editor.remove(it) }
        editor.apply()
    }

    fun isCategoryComplete(counts: Map<String, Int>, category: Category): Boolean =
        category.items.indices.all { i -> (counts["${category.name}-$i"] ?: 0) >= category.items[i].repeat }

    /** يوم مكتمل = أذكار الصباح والمساء مكتملة. */
    fun isDayComplete(context: Context, day: String): Boolean {
        val counts = load(context, day)
        return isCategoryComplete(counts, Category.MORNING) && isCategoryComplete(counts, Category.EVENING)
    }

    /** عدد الأيام المتتالية المكتملة، ويبدأ من اليوم (أو الأمس إن لم يكتمل اليوم بعد). */
    fun streak(context: Context): Int {
        val cal = Calendar.getInstance()
        if (!isDayComplete(context, dayKey(cal))) cal.add(Calendar.DAY_OF_YEAR, -1)
        var count = 0
        while (count < 3650 && isDayComplete(context, dayKey(cal))) {
            count++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return count
    }
}

/** إعدادات العرض. */
object DisplayPrefs {
    private const val PREFS = "settings"
    private const val KEY_FONT = "font_size"
    const val DEFAULT_FONT = 21f

    fun fontSize(context: Context): Float =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_FONT, DEFAULT_FONT)

    fun setFontSize(context: Context, size: Float) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_FONT, size).apply()
    }
}
