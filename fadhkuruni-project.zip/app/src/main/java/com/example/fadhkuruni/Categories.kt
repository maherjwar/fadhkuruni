package com.example.fadhkuruni

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/** تبويبات الأذكار حسب الموضوع، فكل تبويب يجمع أبواباً متقاربة في المعنى. */
enum class Topic(val title: String, val ids: Set<Int>, val icon: ImageVector) {
    MORNING("الصباح والمساء", setOf(27), Icons.Filled.WbSunny),
    SLEEP("النوم والاستيقاظ", setOf(1, 28, 29, 30, 31), Icons.Filled.Bedtime),
    CLOTHES("الثوب واللباس", (2..5).toSet(), Icons.Filled.Checkroom),
    WUDU("الخلاء والوضوء", (6..9).toSet(), Icons.Filled.WaterDrop),
    HOME("البيت", setOf(10, 11), Icons.Filled.Home),
    MOSQUE("المسجد والأذان", (12..15).toSet(), Icons.Filled.Place),
    PRAYER("الصلاة", ((16..26) + setOf(32, 33)).toSet(), Icons.Filled.Star),
    WORRY("الهم والكرب", ((34..46) + setOf(82, 126)).toSet(), Icons.Filled.Shield),
    FAMILY("الأسرة والمجتمع", (setOf(47, 48, 108, 109, 112, 113, 114) + (77..81) + (83..93)).toSet(), Icons.Filled.Group),
    ILLNESS("المرض والجنائز", ((49..60) + setOf(124, 125)).toSet(), Icons.Filled.LocalHospital),
    NATURE("الطبيعة والمطر", ((61..66) + setOf(94, 110, 111)).toSet(), Icons.Filled.Cloud),
    FOOD("الطعام والصيام", (67..76).toSet(), Icons.Filled.Restaurant),
    TRAVEL("السفر", (95..106).toSet(), Icons.Filled.Flight),
    HAJJ("الحج والعمرة", (115..121).toSet(), Icons.Filled.Explore),
    DHIKR("الذكر والاستغفار", (setOf(107, 122, 123) + (127..132)).toSet(), Icons.Filled.Favorite),
}

private val TOPIC_BY_ID: Map<Int, Topic> =
    Topic.entries.flatMap { t -> t.ids.map { id -> id to t } }.toMap()

fun topicOf(chapterId: Int): Topic? = TOPIC_BY_ID[chapterId]

/** أيقونة الباب: أيقونة خاصة لبعض الأبواب، وإلا أيقونة تبويبه. */
fun iconFor(chapter: Chapter): ImageVector = when (chapter.id) {
    1 -> Icons.Filled.Alarm
    15 -> Icons.Filled.Notifications
    28, 67 -> Icons.Filled.NightsStay
    else -> topicOf(chapter.id)?.icon ?: Icons.Filled.Star
}
