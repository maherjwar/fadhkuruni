package com.example.fadhkuruni

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/** مجموعات الأبواب للتصفية والتلوين. */
enum class ChapterGroup(val title: String, val color: Long, val ids: Set<Int>) {
    SLEEP("الاستيقاظ والنوم", 0xFF5C6BC0, setOf(1) + (27..31).toSet()),
    PURITY("الطهارة والبيت", 0xFF0E8A8A, (2..11).toSet()),
    PRAYER("الصلاة والمسجد", 0xFF1B6B50, (12..26).toSet() + setOf(32, 33)),
    WORRY("الهم والكرب", 0xFF8E4B6F, (34..46).toSet() + setOf(82, 124, 125, 126)),
    ILLNESS("المرض والجنائز", 0xFF5D5D5D, (49..60).toSet()),
    FAMILY("الأسرة والمجتمع", 0xFFB0703E, setOf(47, 48, 92, 93) + (77..81).toSet() + (83..91).toSet() + (108..114).toSet()),
    FOOD("الطعام والصيام", 0xFFB08A3E, (67..76).toSet()),
    NATURE("الطبيعة والكون", 0xFF3E7CB0, (61..66).toSet() + setOf(94, 110, 111)),
    TRAVEL("السفر", 0xFFC2185B, (95..106).toSet()),
    HAJJ("الحج والعمرة", 0xFF8D6E63, (115..121).toSet()),
    DHIKR("الذكر والاستغفار", 0xFF6A4FB3, setOf(107, 122, 123) + (127..132).toSet()),
    OTHER("أخرى", 0xFF757575, emptySet()),
}

private val GROUP_BY_ID: Map<Int, ChapterGroup> =
    ChapterGroup.entries.flatMap { g -> g.ids.map { id -> id to g } }.toMap()

fun groupOf(chapterId: Int): ChapterGroup = GROUP_BY_ID[chapterId] ?: ChapterGroup.OTHER

/** أيقونة الباب: أيقونة خاصة لبعض الأبواب، وإلا أيقونة مجموعته. */
fun iconFor(chapter: Chapter): ImageVector = when (chapter.id) {
    1 -> Icons.Filled.Alarm
    2, 3, 4, 5 -> Icons.Filled.Checkroom
    6, 7 -> Icons.Filled.Wc
    8, 9 -> Icons.Filled.WaterDrop
    10 -> Icons.Filled.DirectionsWalk
    11 -> Icons.Filled.Home
    15 -> Icons.Filled.Notifications
    27 -> Icons.Filled.WbSunny
    28 -> Icons.Filled.NightsStay
    29, 30, 31 -> Icons.Filled.Bedtime
    67 -> Icons.Filled.NightsStay
    else -> when (groupOf(chapter.id)) {
        ChapterGroup.SLEEP -> Icons.Filled.Bedtime
        ChapterGroup.PURITY -> Icons.Filled.WaterDrop
        ChapterGroup.PRAYER -> Icons.Filled.Star
        ChapterGroup.WORRY -> Icons.Filled.Shield
        ChapterGroup.ILLNESS -> Icons.Filled.LocalHospital
        ChapterGroup.FAMILY -> Icons.Filled.Group
        ChapterGroup.FOOD -> Icons.Filled.Restaurant
        ChapterGroup.NATURE -> Icons.Filled.Cloud
        ChapterGroup.TRAVEL -> Icons.Filled.Flight
        ChapterGroup.HAJJ -> Icons.Filled.Place
        ChapterGroup.DHIKR -> Icons.Filled.Favorite
        ChapterGroup.OTHER -> Icons.Filled.Star
    }
}
