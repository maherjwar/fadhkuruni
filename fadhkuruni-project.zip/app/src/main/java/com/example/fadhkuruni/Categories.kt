package com.example.fadhkuruni

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/** تبويبات الأذكار حسب الموضوع، وكل تبويب يجمع أبواباً متقاربة في المعنى. */
enum class Topic(val title: String, val ids: Set<Int>, val icon: ImageVector) {
    MORNING("أذكار الصباح والمساء", setOf(27), Icons.Filled.WbSunny),
    SLEEP("أذكار النوم والاستيقاظ", setOf(1, 28, 29, 30, 31), Icons.Filled.Bedtime),
    CLOTHES("أذكار الثوب واللباس", (2..5).toSet(), Icons.Filled.Checkroom),
    WUDU("أذكار الخلاء والوضوء", (6..9).toSet(), Icons.Filled.WaterDrop),
    HOME("أذكار البيت", setOf(10, 11), Icons.Filled.Home),
    MOSQUE("أذكار المسجد والأذان", (12..15).toSet(), CustomIcons.Mosque),
    PRAYER("أذكار الصلاة", ((16..26) + setOf(32, 33)).toSet(), Icons.Filled.AccessTime),
    WORRY("أذكار الهم والكرب", ((34..46) + setOf(82, 126)).toSet(), Icons.Filled.Shield),
    FAMILY("أذكار الأسرة والمجتمع",
        (setOf(47, 48, 108, 109, 112, 113, 114) + (77..81) + (83..93)).toSet(), Icons.Filled.Group),
    HEALTH("أذكار الصحة والعافية", setOf(49, 50, 51, 53, 124, 125), Icons.Filled.Spa),
    FUNERAL("أذكار الجنائز والقبور", (setOf(52) + (54..60)).toSet(), Icons.Filled.Park),
    NATURE("أذكار الطبيعة والمطر", ((61..66) + setOf(94, 110, 111)).toSet(), Icons.Filled.Cloud),
    FOOD("أذكار الطعام والصيام", (67..76).toSet(), Icons.Filled.Restaurant),
    TRAVEL("أذكار السفر", (95..106).toSet(), Icons.Filled.Flight),
    HAJJ("أذكار الحج والعمرة", (115..121).toSet(), Icons.Filled.Explore),
    TASBIH("أذكار التسبيح والاستغفار", setOf(107, 129, 130, 131, 132), Icons.Filled.Favorite),
    MISC("أذكار متنوعة", setOf(122, 123, 127, 128), Icons.Filled.Star),
}

private val TOPIC_BY_ID: Map<Int, Topic> =
    Topic.entries.flatMap { t -> t.ids.map { id -> id to t } }.toMap()

fun topicOf(chapterId: Int): Topic? = TOPIC_BY_ID[chapterId]

/** أيقونة الباب: أيقونة خاصة لبعض الأبواب، وإلا أيقونة تبويبه. */
fun iconFor(chapter: Chapter): ImageVector = when (chapter.id) {
    1 -> Icons.Filled.Alarm
    28, 67 -> Icons.Filled.NightsStay
    else -> topicOf(chapter.id)?.icon ?: Icons.Filled.Star
}
