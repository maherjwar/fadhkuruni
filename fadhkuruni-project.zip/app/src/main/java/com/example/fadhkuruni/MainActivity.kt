package com.example.fadhkuruni

import android.Manifest
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val systemDark = isSystemInDarkTheme()
            var dark by remember { mutableStateOf(ThemePrefs.isDark(this@MainActivity, systemDark)) }
            AdhkarTheme(darkTheme = dark) {
                // تخطيط من اليمين إلى اليسار للعربية
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AdhkarApp(
                        isDark = dark,
                        onToggleTheme = {
                            dark = !dark
                            ThemePrefs.setDark(this@MainActivity, dark)
                        },
                    )
                }
            }
        }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    CHAPTERS("الأبواب", Icons.Filled.MenuBook),
    FREE("السبحة", Icons.Filled.TouchApp),
    SERVICES("الخدمات", Icons.Filled.Apps),
    SETTINGS("الإعدادات", Icons.Filled.Settings),
}

private enum class DhikrStatus { NOT_STARTED, IN_PROGRESS, DONE }

private fun statusOf(done: Int, repeat: Int): DhikrStatus = when {
    done >= repeat -> DhikrStatus.DONE
    done > 0 -> DhikrStatus.IN_PROGRESS
    else -> DhikrStatus.NOT_STARTED
}

/** عدد الأذكار المكتملة في باب معيّن. */
private fun doneItems(counts: Map<String, Int>, chapter: Chapter): Int =
    chapter.items.indices.count { i -> (counts[CounterStore.key(chapter, i)] ?: 0) >= chapter.items[i].repeat }

/** تحويل الأرقام إلى الأرقام العربية (٠١٢...). */
fun arabicNumber(n: Int, minDigits: Int = 1): String =
    n.toString().padStart(minDigits, '0')
        .map { c -> if (c.isDigit()) '٠' + (c - '0') else c }
        .joinToString("")

fun formatTime(hour: Int, minute: Int): String {
    val period = if (hour < 12) "ص" else "م"
    val h12 = if (hour % 12 == 0) 12 else hour % 12
    return "${arabicNumber(h12)}:${arabicNumber(minute, 2)} $period"
}

/** تطبيع النص العربي للبحث: إزالة التشكيل والتطويل وتوحيد الألفات والياء والتاء المربوطة. */
fun normalizeAr(s: String): String = s
    .replace(Regex("[ً-ٰٟـ]"), "")
    .replace('أ', 'ا')
    .replace('إ', 'ا')
    .replace('آ', 'ا')
    .replace('ى', 'ي')
    .replace('ة', 'ه')

private fun gregorianDate(): String =
    SimpleDateFormat("EEEE d MMMM yyyy", Locale.forLanguageTag("ar")).format(Date())

/** عنوان قصير لذكر: أول أربع كلمات. */
fun shortTitle(text: String): String {
    val words = text.split(' ').filter { it.isNotBlank() }
    return words.take(4).joinToString(" ") + (if (words.size > 4) " …" else "")
}

private fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

private fun shareDhikr(context: Context, dhikr: Dhikr, chapterTitle: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "${dhikr.text}\n\n— $chapterTitle")
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة الذكر"))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdhkarApp(isDark: Boolean, onToggleTheme: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var today by remember { mutableStateOf(CounterStore.today()) }
    val counts = remember {
        mutableStateMapOf<String, Int>().apply { putAll(CounterStore.load(context, CounterStore.today())) }
    }
    var fontSize by remember { mutableFloatStateOf(DisplayPrefs.fontSize(context)) }
    var fontChoice by remember { mutableIntStateOf(DisplayPrefs.fontChoice(context)) }
    var tab by remember { mutableStateOf(Tab.CHAPTERS) }
    var openTopic by remember { mutableStateOf<Topic?>(null) }
    var openChapter by remember { mutableStateOf<Chapter?>(null) }
    var openIndices by remember { mutableStateOf<List<Int>?>(null) }
    var openTitle by remember { mutableStateOf<String?>(null) }
    var openQibla by remember { mutableStateOf(false) }
    var lastChapter by remember {
        mutableStateOf(AppState.lastChapterId(context)?.let { id -> HISN_CHAPTERS.firstOrNull { it.id == id } })
    }
    var showResetAll by remember { mutableStateOf(false) }

    // إعادة تحميل العدادات عند العودة إلى التطبيق، لأن اليوم قد يكون تغيّر
    fun reload() {
        today = CounterStore.today()
        counts.clear()
        counts.putAll(CounterStore.load(context, today))
        ProgressWidget.updateAll(context)
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) reload()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val setCount: (String, Int) -> Unit = { key, value ->
        counts[key] = value
        CounterStore.save(context, today, key, value)
        ProgressWidget.updateAll(context)
    }

    fun openEntry(chapter: Chapter, part: List<Int>?, title: String?) {
        AppState.setLastChapterId(context, chapter.id)
        lastChapter = chapter
        openIndices = part
        openTitle = title
        openChapter = chapter
    }

    fun closeChapter() {
        openChapter = null
        openIndices = null
        openTitle = null
    }

    // الرجوع يعيدنا خطوة واحدة: من الذكر إلى الموضوع، ومنه إلى الرئيسية
    BackHandler(enabled = openChapter != null || openTopic != null || openQibla) {
        when {
            openChapter != null -> closeChapter()
            openTopic != null -> openTopic = null
            else -> openQibla = false
        }
    }

    val chapter = openChapter
    val parts = openIndices
    val topic = openTopic
    val inDetail = chapter != null || topic != null || openQibla

    Scaffold(
        topBar = {
            when {
                chapter != null -> CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = openTitle ?: chapter.title,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { closeChapter() }) {
                            Icon(Icons.Filled.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                )
                topic != null -> CenterAlignedTopAppBar(
                    title = {
                        Text(topic.title, style = MaterialTheme.typography.titleLarge, maxLines = 1)
                    },
                    navigationIcon = {
                        IconButton(onClick = { openTopic = null }) {
                            Icon(Icons.Filled.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                )
                openQibla -> CenterAlignedTopAppBar(
                    title = { Text("القبلة", style = MaterialTheme.typography.titleLarge) },
                    navigationIcon = {
                        IconButton(onClick = { openQibla = false }) {
                            Icon(Icons.Filled.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                )
                tab == Tab.CHAPTERS -> Unit
                else -> CenterAlignedTopAppBar(
                    title = { Text(tab.label, style = MaterialTheme.typography.titleLarge) },
                )
            }
        },
        bottomBar = {
            if (!inDetail) {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label) },
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            when {
                chapter != null -> ChapterScreen(
                    chapter = chapter,
                    counts = counts,
                    fontSize = fontSize,
                    fontFamily = bodyFont(fontChoice),
                    setCount = setCount,
                    part = parts,
                )
                topic != null -> TopicScreen(
                    topic = topic,
                    counts = counts,
                    onOpenChapter = { c, p, t -> openEntry(c, p, t) },
                )
                openQibla -> QiblaScreen()
                else -> when (tab) {
                    Tab.CHAPTERS -> HomeScreen(
                        isDark = isDark,
                        onToggleTheme = onToggleTheme,
                        counts = counts,
                        lastChapter = lastChapter,
                        onOpenTopic = { t -> openTopic = t },
                        onOpenChapter = { c, p, t -> openEntry(c, p, t) },
                    )
                    Tab.FREE -> FreeCounterScreen()
                    Tab.SERVICES -> ServicesScreen(onOpenQibla = { openQibla = true })
                    Tab.SETTINGS -> SettingsScreen(
                        fontSize = fontSize,
                        fontChoice = fontChoice,
                        onFontSizeChange = { size ->
                            fontSize = size
                            DisplayPrefs.setFontSize(context, size)
                        },
                        onFontChoiceChange = { choice ->
                            fontChoice = choice
                            DisplayPrefs.setFontChoice(context, choice)
                        },
                        onDataChanged = { reload() },
                        onResetToday = { showResetAll = true },
                    )
                }
            }
        }
    }

    if (showResetAll) {
        AlertDialog(
            onDismissRequest = { showResetAll = false },
            title = { Text("إعادة أذكار اليوم؟") },
            text = { Text("سيتم تصفير جميع العدادات لليوم الحالي.") },
            confirmButton = {
                TextButton(onClick = {
                    CounterStore.resetDay(context, today)
                    counts.clear()
                    ProgressWidget.updateAll(context)
                    showResetAll = false
                }) { Text("نعم، أعد") }
            },
            dismissButton = { TextButton(onClick = { showResetAll = false }) { Text("إلغاء") } },
        )
    }
}

// ---------------------------------------------------------------- الرئيسية

@Composable
fun HomeScreen(
    counts: Map<String, Int>,
    isDark: Boolean,
    onToggleTheme: () -> Unit,
    lastChapter: Chapter?,
    onOpenTopic: (Topic) -> Unit,
    onOpenChapter: (Chapter, List<Int>?, String?) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val needle = normalizeAr(query.trim())
    val matches = HISN_CHAPTERS.filter { ch ->
        needle.isNotEmpty() && (
            normalizeAr(ch.title).contains(needle) ||
                ch.items.any { normalizeAr(it.text).contains(needle) })
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { HomeHeader(isDark = isDark, onToggleTheme = onToggleTheme) }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("ابحث عن باب أو ذكر") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "مسح البحث")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            )
        }

        if (lastChapter != null && needle.isEmpty()) {
            item {
                ContinueCard(
                    chapter = lastChapter,
                    onClick = { onOpenChapter(lastChapter, null, null) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                )
            }
        }

        if (needle.isEmpty()) {
            // أذكار الصباح والمساء بطاقتان منفصلتان، وباقي المواضيع بطاقة لكل موضوع
            val tiles = buildList<HomeTile> {
                Topic.entries.forEach { t ->
                    val morningChapter = HISN_CHAPTERS.firstOrNull { it.id == 27 }
                    if (t == Topic.MORNING && morningChapter != null) {
                        val ch = morningChapter
                        val parts = listOf(
                            Triple("أذكار الصباح", Icons.Filled.WbSunny, (0 until EVENING_START).toList()),
                            Triple("أذكار المساء", Icons.Filled.DarkMode, (EVENING_START until ch.items.size).toList()),
                        )
                        parts.forEach { (title, icon, part) ->
                            add(
                                HomeTile(
                                    title = title,
                                    icon = icon,
                                    done = part.count { i -> (counts[CounterStore.key(ch, i)] ?: 0) >= ch.items[i].repeat },
                                    total = part.size,
                                    onClick = { onOpenChapter(ch, part, title) },
                                )
                            )
                        }
                    } else {
                        val chapters = HISN_CHAPTERS.filter { it.id in t.ids }
                        add(
                            HomeTile(
                                title = t.title,
                                icon = t.icon,
                                done = chapters.sumOf { doneItems(counts, it) },
                                total = chapters.sumOf { it.items.size },
                                onClick = { onOpenTopic(t) },
                            )
                        )
                    }
                }
            }
            items(tiles.chunked(2), key = { row -> row.first().title }) { row ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    row.forEach { t ->
                        TopicTile(
                            title = t.title,
                            icon = t.icon,
                            done = t.done,
                            total = t.total,
                            onClick = t.onClick,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        } else if (matches.isEmpty()) {
            item {
                Text(
                    text = "لا توجد نتائج مطابقة",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
                )
            }
        } else {
            items(matches.chunked(2), key = { row -> row.first().id }) { row ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    row.forEach { ch ->
                        ChapterCard(
                            title = ch.title,
                            complete = doneItems(counts, ch) >= ch.items.size,
                            onClick = { onOpenChapter(ch, null, null) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

/** رأس أخضر بالتاريخ الهجري والميلادي وعدد أذكار اليوم. */
/** نقش هندسي إسلامي خفيف: شبكة من النجوم الثمانية. */
private fun DrawScope.islamicPattern() {
    val cell = 36.dp.toPx()
    val tint = Color.White.copy(alpha = 0.10f)
    val rows = (size.height / cell).toInt() + 2
    val cols = (size.width / cell).toInt() + 2
    for (r in 0..rows) {
        for (c in 0..cols) {
            val cx = c * cell + if (r % 2 == 1) cell / 2f else 0f
            val cy = r * cell
            val path = Path()
            for (k in 0 until 16) {
                val rad = if (k % 2 == 0) cell * 0.5f else cell * 0.2f
                val ang = Math.toRadians(k * 22.5 - 90.0)
                val x = cx + rad * Math.cos(ang).toFloat()
                val y = cy + rad * Math.sin(ang).toFloat()
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            drawPath(path, tint, style = Stroke(width = 1.dp.toPx()))
        }
    }
}

@Composable
fun HomeHeader(isDark: Boolean, onToggleTheme: () -> Unit) {
    val context = LocalContext.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF2F7D4F), Color(0xFF1C4D2E)))),
    ) {
        Canvas(modifier = Modifier.matchParentSize()) { islamicPattern() }
        Column(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(bottom = 28.dp),
        ) {
            // في الاتجاه العربي، End هو الجهة اليسرى
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.End,
            ) {
                IconButton(onClick = onToggleTheme) {
                    Icon(
                        imageVector = if (isDark) Icons.Filled.NightsStay else Icons.Filled.WbSunny,
                        contentDescription = if (isDark) "الوضع الليلي، اضغط للتبديل" else "الوضع الفاتح، اضغط للتبديل",
                        tint = Color.White,
                    )
                }
            }
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = hijriDate(context),
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = gregorianDate(),
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

/** عنصر في الشاشة الرئيسية: موضوع، أو قسم من باب الصباح والمساء. */
private class HomeTile(
    val title: String,
    val icon: ImageVector,
    val done: Int,
    val total: Int,
    val onClick: () -> Unit,
)

@Composable
fun TopicTile(
    title: String,
    icon: ImageVector,
    done: Int,
    total: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val complete = total > 0 && done >= total

    Card(
        onClick = onClick,
        modifier = modifier.height(168.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (complete) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface,
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.size(52.dp),
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(28.dp),
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "${arabicNumber(done)} من ${arabicNumber(total)} ذكراً",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
@Composable
fun TopicScreen(
    topic: Topic,
    counts: Map<String, Int>,
    onOpenChapter: (Chapter, List<Int>?, String?) -> Unit,
) {
    val chapters = HISN_CHAPTERS.filter { it.id in topic.ids }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (topic == Topic.MORNING) {
            // أذكار الصباح والمساء: بطاقة لكل قسم، ولكل منها أيقونتها
            val ch = chapters.first()
            val morning = (0 until EVENING_START).toList()
            val evening = (EVENING_START until ch.items.size).toList()
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    PartCard(
                        title = "أذكار الصباح",
                        icon = Icons.Filled.WbSunny,
                        complete = morning.all { i -> (counts[CounterStore.key(ch, i)] ?: 0) >= ch.items[i].repeat },
                        onClick = { onOpenChapter(ch, morning, "أذكار الصباح") },
                    )
                    PartCard(
                        title = "أذكار المساء",
                        icon = Icons.Filled.DarkMode,
                        complete = evening.all { i -> (counts[CounterStore.key(ch, i)] ?: 0) >= ch.items[i].repeat },
                        onClick = { onOpenChapter(ch, evening, "أذكار المساء") },
                    )
                }
            }
        } else {
            items(chapters.chunked(2), key = { row -> row.first().id }) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { ch ->
                        ChapterCard(
                            title = ch.title,
                            complete = doneItems(counts, ch) >= ch.items.size,
                            onClick = { onOpenChapter(ch, null, null) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

/** بطاقة باب أو ذكر: عنوان في المنتصف بلا أرقام ولا أشرطة تقدم. */
@Composable
fun ChapterCard(
    title: String,
    complete: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        modifier = modifier.height(100.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (complete) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface,
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
fun ContinueCard(chapter: Chapter, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Bookmark, contentDescription = null)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("متابعة القراءة", style = MaterialTheme.typography.labelMedium)
                Text(chapter.title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
            }
        }
    }
}

// ---------------------------------------------------------------- الباب والذكر

/** يعرض باباً كاملاً، أو جزءاً منه (صباح أو مساء) إذا حُدّد [part]. */
@Composable
fun ChapterScreen(
    chapter: Chapter,
    counts: Map<String, Int>,
    fontSize: Float,
    fontFamily: FontFamily,
    setCount: (String, Int) -> Unit,
    part: List<Int>?,
) {
    val context = LocalContext.current
    val dhikrs = chapter.items
    val done = doneItems(counts, chapter)
    val shown = part ?: dhikrs.indices.toList()

    Column(modifier = Modifier.fillMaxSize()) {
        if (part == null) {
            Text(
                text = "تم ${arabicNumber(done)} من ${arabicNumber(dhikrs.size)}",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            )
        }
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(shown) { index ->
                val dhikr = dhikrs[index]
                val key = CounterStore.key(chapter, index)
                val count = counts[key] ?: 0
                DhikrCard(
                    dhikr = dhikr,
                    done = count,
                    fontSize = fontSize,
                    fontFamily = fontFamily,
                    onIncrement = { if (count < dhikr.repeat) setCount(key, count + 1) },
                    onDecrement = { if (count > 0) setCount(key, count - 1) },
                    onReset = { setCount(key, 0) },
                    onShare = { shareDhikr(context, dhikr, chapter.title) },
                )
            }
        }
    }
}

@Composable
fun DhikrCard(
    dhikr: Dhikr,
    done: Int,
    fontSize: Float,
    fontFamily: FontFamily,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onReset: () -> Unit,
    onShare: () -> Unit,
) {
    val status = statusOf(done, dhikr.repeat)
    val haptic = LocalHapticFeedback.current
    val (icon, tint) = when (status) {
        DhikrStatus.DONE -> Icons.Filled.CheckCircle to MaterialTheme.colorScheme.primary
        DhikrStatus.IN_PROGRESS -> Icons.Filled.HourglassTop to MaterialTheme.colorScheme.secondary
        DhikrStatus.NOT_STARTED -> Icons.Outlined.RadioButtonUnchecked to MaterialTheme.colorScheme.onSurfaceVariant
    }
    val statusLabel = when (status) {
        DhikrStatus.DONE -> "تم ✓"
        DhikrStatus.IN_PROGRESS, DhikrStatus.NOT_STARTED -> "${arabicNumber(done)} من ${arabicNumber(dhikr.repeat)}"
    }

    Card(
        modifier = Modifier.fillMaxWidth().pointerInput(done, dhikr.repeat) {
            detectTapGestures(
                onTap = {
                    if (done < dhikr.repeat) {
                        onIncrement()
                        haptic.performHapticFeedback(
                            if (done + 1 >= dhikr.repeat) HapticFeedbackType.LongPress
                            else HapticFeedbackType.TextHandleMove
                        )
                    }
                },
                onLongPress = {
                    if (done > 0) {
                        onDecrement()
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                },
            )
        },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (status == DhikrStatus.DONE) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = dhikr.text,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontFamily = fontFamily,
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.9f).sp,
                ),
                textAlign = TextAlign.Justify,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(14.dp))
            if (status != DhikrStatus.DONE) {
                Text(
                    text = "اضغط على نص الذكر للعد، واضغط مطولاً للتراجع",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = tint,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onShare) {
                    Icon(Icons.Filled.Share, contentDescription = "مشاركة الذكر")
                }
                IconButton(onClick = onReset) {
                    Icon(Icons.Filled.Refresh, contentDescription = "تصفير هذا الذكر")
                }
            }
        }
    }
}

/** عداد دائري بالرقم فقط: الضغطة تزيد، والضغط المطوّل ينقص. */
@Composable
fun CounterButton(
    done: Int,
    repeat: Int,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val complete = done >= repeat

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (complete) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer,
        contentColor = if (complete) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer,
        modifier = Modifier
            .size(width = 120.dp, height = 80.dp)
            .pointerInput(done, repeat) {
                detectTapGestures(
                    onTap = {
                        if (done < repeat) {
                            onIncrement()
                            haptic.performHapticFeedback(
                                if (done + 1 >= repeat) HapticFeedbackType.LongPress
                                else HapticFeedbackType.TextHandleMove
                            )
                        }
                    },
                    onLongPress = {
                        if (done > 0) {
                            onDecrement()
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        }
                    },
                )
            }
            .semantics {
                role = Role.Button
                contentDescription = "عداد الذكر: ${arabicNumber(done)} من ${arabicNumber(repeat)}"
            },
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = arabicNumber(done), style = MaterialTheme.typography.titleLarge)
                Text(text = "من ${arabicNumber(repeat)}", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

// ---------------------------------------------------------------- عداد حر

@Composable
fun FreeCounterScreen() {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var value by remember { mutableIntStateOf(AppState.freeCounter(context)) }
    var confirmReset by remember { mutableStateOf(false) }

    fun update(newValue: Int) {
        value = newValue
        AppState.setFreeCounter(context, newValue)
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("السبحة", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        Text(
            text = arabicNumber(value),
            style = MaterialTheme.typography.displaySmall.copy(fontSize = 72.sp),
        )
        Spacer(Modifier.height(24.dp))
        Surface(
            onClick = {
                update(value + 1)
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            },
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(200.dp),
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Text("اضغط للعد", style = MaterialTheme.typography.titleLarge)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { if (value > 0) update(value - 1) }) { Text("تراجع") }
            OutlinedButton(onClick = { confirmReset = true }) { Text("تصفير") }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("تصفير العداد؟") },
            confirmButton = {
                TextButton(onClick = {
                    update(0)
                    confirmReset = false
                }) { Text("نعم، صفّر") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("إلغاء") } },
        )
    }
}

// ---------------------------------------------------------------- الخدمات

@Composable
fun ServicesScreen(onOpenQibla: () -> Unit) {
    val context = LocalContext.current
    val occasions = remember { upcomingOccasions(context) }
    var showHijri by remember { mutableStateOf(false) }
    if (showHijri) HijriMonthDialog(onDismiss = { showHijri = false })
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ServiceCard(title = "القبلة", icon = Icons.Filled.Explore, onClick = onOpenQibla) {
                Text(
                    "اضغط لفتح بوصلة القبلة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            ServiceCard(title = "التاريخ الهجري", icon = Icons.Filled.CalendarMonth, onClick = { showHijri = true }) { HijriContent() }
        }
        item {
            ServiceCard(title = "المناسبات", icon = Icons.Filled.DateRange) { OccasionsContent(occasions) }
        }
    }
}

@Composable
fun ServiceCard(
    title: String,
    icon: ImageVector,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    Card(
        onClick = { onClick?.invoke() },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun HijriContent() {
    val context = LocalContext.current
    Text(hijriDate(context), style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(4.dp))
    Text(gregorianDate(), style = MaterialTheme.typography.bodyLarge)
    Spacer(Modifier.height(8.dp))
    Text(
        "إن اختلف التاريخ عن الرسمي، اضبطه من تبويب الإعدادات.",
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
fun OccasionsContent(list: List<UpcomingOccasion>) {
    list.forEachIndexed { i, up ->
        if (i > 0) HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(up.occasion.name, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(2.dp))
                Text(occasionHijriLabel(up), style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = occasionGregorianLabel(up.date),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.width(12.dp))
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.size(66.dp),
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(arabicNumber(up.daysLeft), style = MaterialTheme.typography.titleLarge)
                    Text("يوماً", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
    Spacer(Modifier.height(8.dp))
    Text(
        "التواريخ تقريبية وقد تختلف بيوم حسب رؤية الهلال.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

/** صفحة القبلة: بوصلة دائرية، وتعمل المستشعرات عند الدخول إليها فقط. */
@Composable
fun QiblaScreen() {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasLocationPermission(context)) }
    var bearing by remember { mutableStateOf<Double?>(null) }
    var heading by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf<String?>(null) }
    var refreshKey by remember { mutableIntStateOf(0) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> granted = ok }

    LaunchedEffect(granted, refreshKey) {
        if (granted) {
            val loc = Qibla.lastLocation(context)
            if (loc != null) {
                bearing = Qibla.bearing(loc.latitude, loc.longitude)
                status = null
            } else {
                bearing = null
                status = "تعذّر تحديد موقعك. فعّل الموقع ثم اضغط تحديث."
            }
        } else {
            status = "اسمح بالوصول إلى الموقع لحساب اتجاه القبلة."
        }
    }

    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val listener = object : SensorEventListener {
            private val rotation = FloatArray(9)
            private val orientation = FloatArray(3)

            override fun onSensorChanged(event: SensorEvent) {
                SensorManager.getRotationMatrixFromVector(rotation, event.values)
                SensorManager.getOrientation(rotation, orientation)
                heading = ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(listener) }
    }

    val b = bearing
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (b != null) {
            QiblaDial(bearing = b, heading = heading)
        } else {
            Spacer(Modifier.height(40.dp))
            Text(
                text = status ?: "جارٍ تحديد الموقع…",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            if (!granted) {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = {
                    permissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                }) { Text("السماح بالموقع") }
            }
            Spacer(Modifier.height(40.dp))
        }

        Spacer(Modifier.height(24.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    QiblaTile(Icons.Filled.LocationOn)
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("الموقع", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = if (b != null) "تم تحديد موقعك" else (status ?: "…"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    TextButton(onClick = { refreshKey++ }) {
                        Text("تحديث")
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    QiblaTile(Icons.Filled.Explore)
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("اتجاه البوصلة", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "اتجاه الهاتف الآن",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        text = "${arabicNumber(heading.toInt())}°",
                        style = MaterialTheme.typography.titleLarge,
                    )
                }
            }
        }
    }
}

@Composable
private fun QiblaTile(icon: ImageVector) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = Modifier.size(52.dp),
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
        }
    }
}

/**
 * القرص: الشمال يبقى في أعلى الدائرة الحقيقي (يدور القرص عكس الهاتف)،
 * والكعبة على المحيط في زاوية القبلة، ومؤشر الإبرة يمتد من المركز نحوها.
 */
@Composable
private fun QiblaDial(bearing: Double, heading: Float) {
    val surface = MaterialTheme.colorScheme.surface
    val band = MaterialTheme.colorScheme.secondaryContainer
    val line = MaterialTheme.colorScheme.outlineVariant
    val ink = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val accent = MaterialTheme.colorScheme.primary

    Box(modifier = Modifier.size(300.dp), contentAlignment = Alignment.Center) {
        Box(modifier = Modifier.fillMaxSize().rotate(-heading)) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val r = size.minDimension / 2f
                drawCircle(color = band, radius = r, center = c)
                drawCircle(color = surface, radius = r * 0.72f, center = c)
                drawCircle(color = line, radius = r * 0.72f, center = c, style = Stroke(width = 1.dp.toPx()))
                for (i in 0 until 72) {
                    val rad = Math.toRadians(i * 5.0)
                    val sn = Math.sin(rad).toFloat()
                    val cs = Math.cos(rad).toFloat()
                    val major = i % 6 == 0
                    val from = r * (if (major) 0.86f else 0.93f)
                    val to = r * 0.98f
                    drawLine(
                        color = if (major) ink else muted,
                        start = Offset(c.x + from * sn, c.y - from * cs),
                        end = Offset(c.x + to * sn, c.y - to * cs),
                        strokeWidth = (if (major) 2.dp else 1.dp).toPx(),
                        cap = StrokeCap.Round,
                    )
                }
            }
            for (a in 0 until 360 step 30) {
                val cardinal = a % 90 == 0
                val label = when (a) {
                    0 -> "N"
                    90 -> "E"
                    180 -> "S"
                    270 -> "W"
                    else -> arabicNumber(a)
                }
                Box(modifier = Modifier.fillMaxSize().rotate(a.toFloat())) {
                    Text(
                        text = label,
                        style = if (cardinal) MaterialTheme.typography.titleSmall else MaterialTheme.typography.labelSmall,
                        fontWeight = if (cardinal) FontWeight.Bold else FontWeight.Normal,
                        color = if (cardinal) accent else muted,
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 22.dp),
                    )
                }
            }
            // الإبرة والكعبة تدوران مع زاوية القبلة
            Box(modifier = Modifier.fillMaxSize().rotate(bearing.toFloat())) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val r = size.minDimension / 2f
                    drawLine(
                        color = ink,
                        start = c,
                        end = Offset(c.x, c.y - r * 0.70f),
                        strokeWidth = 4.dp.toPx(),
                        cap = StrokeCap.Round,
                    )
                }
                Surface(
                    modifier = Modifier.align(Alignment.TopCenter).size(40.dp),
                    shape = CircleShape,
                    color = surface,
                    border = BorderStroke(1.dp, line),
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Canvas(modifier = Modifier.size(24.dp)) {
                            drawRect(color = Color(0xFF111111))
                            drawRect(
                                color = Color(0xFFE0A526),
                                topLeft = Offset(0f, size.height * 0.30f),
                                size = Size(size.width, size.height * 0.12f),
                            )
                        }
                    }
                }
            }
        }
        // مركز البوصلة يعرض زاوية القبلة ثابتاً
        Box(
            modifier = Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(band)
                .border(1.dp, line, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("القبلة", style = MaterialTheme.typography.labelLarge, color = muted)
                Text(
                    text = "${arabicNumber(Math.round(bearing).toInt())}°",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = ink,
                )
            }
        }
        // المؤشر الثابت يمثل مقدمة الهاتف
        Icon(
            imageVector = Icons.Filled.ArrowDropUp,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.align(Alignment.TopCenter).offset(y = (-8).dp).size(32.dp),
        )
    }
}

// ---------------------------------------------------------------- الإعدادات

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    fontSize: Float,
    fontChoice: Int,
    onFontSizeChange: (Float) -> Unit,
    onFontChoiceChange: (Int) -> Unit,
    onDataChanged: () -> Unit,
    onResetToday: () -> Unit,
) {
    val context = LocalContext.current
    val configs = remember {
        mutableStateListOf<ReminderConfig>().apply { addAll(Reminders.load(context)) }
    }
    var followUp by remember { mutableStateOf(Reminders.isFollowUpEnabled(context)) }
    var hijriOffset by remember { mutableIntStateOf(HijriPrefs.offset(context)) }
    var editingIndex by remember { mutableStateOf<Int?>(null) }
    var pendingAfterPermission by remember { mutableStateOf<(() -> Unit)?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingAfterPermission
        pendingAfterPermission = null
        if (granted) action?.invoke()
        else context.toast("لن تصل التذكيرات بدون إذن الإشعارات")
    }

    // عند التفعيل نطلب الإذن أولاً، ولا يُحفظ التفعيل إلا إذا مُنح
    fun withNotificationPermission(enabling: Boolean, action: () -> Unit) {
        if (enabling && !Reminders.hasNotificationPermission(context)) {
            pendingAfterPermission = action
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            action()
        }
    }

    fun setReminderEnabled(index: Int, on: Boolean) {
        withNotificationPermission(on) {
            val updated = configs[index].copy(enabled = on)
            configs[index] = updated
            Reminders.save(context, updated)
        }
    }

    fun setFollowUp(on: Boolean) {
        withNotificationPermission(on) {
            followUp = on
            Reminders.setFollowUpEnabled(context, on)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("التذكيرات", style = MaterialTheme.typography.titleMedium)
        configs.forEachIndexed { index, config ->
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(config.kind.title, style = MaterialTheme.typography.bodyLarge)
                    TextButton(
                        onClick = { editingIndex = index },
                        contentPadding = PaddingValues(0.dp),
                    ) {
                        Text("الوقت: ${formatTime(config.hour, config.minute)}")
                    }
                }
                Switch(
                    checked = config.enabled,
                    onCheckedChange = { on -> setReminderEnabled(index, on) },
                )
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("متابعة أذكار الصباح", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "تذكير بعد ساعة ونصف إن لم تكتمل",
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            Switch(checked = followUp, onCheckedChange = { on -> setFollowUp(on) })
        }

        HorizontalDivider()

        Text("التاريخ الهجري", style = MaterialTheme.typography.titleMedium)
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("ضبط التاريخ الهجري", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "للتعديل إن اختلف التاريخ عن الرسمي",
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            IconButton(onClick = {
                if (hijriOffset > -2) {
                    hijriOffset--
                    HijriPrefs.setOffset(context, hijriOffset)
                }
            }) {
                Icon(Icons.Filled.Remove, contentDescription = "تقليل يوم")
            }
            Text(hijriOffsetLabel(hijriOffset), style = MaterialTheme.typography.labelMedium)
            IconButton(onClick = {
                if (hijriOffset < 2) {
                    hijriOffset++
                    HijriPrefs.setOffset(context, hijriOffset)
                }
            }) {
                Icon(Icons.Filled.Add, contentDescription = "زيادة يوم")
            }
        }

        HorizontalDivider()

        Text("حجم الخط", style = MaterialTheme.typography.titleMedium)
        Text(
            text = "بسم الله الرحمن الرحيم",
            style = MaterialTheme.typography.bodyLarge.copy(
                fontFamily = bodyFont(fontChoice),
                fontSize = fontSize.sp,
            ),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Slider(
            value = fontSize,
            onValueChange = onFontSizeChange,
            valueRange = 16f..30f,
            steps = 6,
        )

        Text("نوع الخط", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = fontChoice == 0,
                onClick = { onFontChoiceChange(0) },
                label = { Text("قمرة") },
            )
            FilterChip(
                selected = fontChoice == 1,
                onClick = { onFontChoiceChange(1) },
                label = { Text("النظام") },
            )
        }

        HorizontalDivider()

        Text("اليوم", style = MaterialTheme.typography.titleMedium)
        OutlinedButton(onClick = onResetToday) { Text("إعادة أذكار اليوم") }

    }

    editingIndex?.let { index ->
        val config = configs[index]
        TimePickerDialog(
            initialHour = config.hour,
            initialMinute = config.minute,
            onConfirm = { hour, minute ->
                val updated = config.copy(hour = hour, minute = minute)
                configs[index] = updated
                Reminders.save(context, updated)
                editingIndex = null
            },
            onDismiss = { editingIndex = null },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerDialog(
    initialHour: Int,
    initialMinute: Int,
    onConfirm: (Int, Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val state = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = false,
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onConfirm(state.hour, state.minute) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        text = { TimePicker(state = state) },
    )
}

/** بطاقة عريضة لقسم من الباب (صباح أو مساء). */
@Composable
fun PartCard(title: String, icon: ImageVector, complete: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(88.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (complete) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface,
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(16.dp))
            Text(title, style = MaterialTheme.typography.titleMedium)
        }
    }
}

/** التقويم الهجري للشهر الحالي، والأيام البيض (13 و14 و15) مميزة. */
@Composable
fun HijriMonthDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var shift by remember { mutableIntStateOf(0) }
    val info = remember(shift) { hijriMonthInfo(context, shift) }
    val weekdays = listOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")
    val cells: List<Int?> = List(info.firstWeekday) { null } + (1..info.days).toList()
    val rows = cells.chunked(7)

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } },
        dismissButton = {
            if (shift != 0) TextButton(onClick = { shift = 0 }) { Text("الشهر الحالي") }
        },
        title = {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                // في الاتجاه العربي: اليمين للماضي، واليسار للقادم
                IconButton(onClick = { shift-- }) {
                    Icon(Icons.Filled.ChevronRight, contentDescription = "الشهر السابق")
                }
                Text(
                    info.title,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { shift++ }) {
                    Icon(Icons.Filled.ChevronLeft, contentDescription = "الشهر التالي")
                }
            }
        },
        text = {
            Column {
                Row(modifier = Modifier.fillMaxWidth()) {
                    weekdays.forEach { d ->
                        Text(
                            d,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                rows.forEach { row ->
                    Row(modifier = Modifier.fillMaxWidth()) {
                        for (i in 0 until 7) {
                            val day = row.getOrNull(i)
                            Box(
                                modifier = Modifier.weight(1f).padding(3.dp).aspectRatio(1f),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (day != null) {
                                    val isToday = day == info.today
                                    val isWhite = day in 13..15
                                    val bg = when {
                                        isToday -> MaterialTheme.colorScheme.primary
                                        isWhite -> MaterialTheme.colorScheme.secondaryContainer
                                        else -> Color.Transparent
                                    }
                                    val fg = when {
                                        isToday -> MaterialTheme.colorScheme.onPrimary
                                        isWhite -> MaterialTheme.colorScheme.onSecondaryContainer
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                    Box(
                                        modifier = Modifier.fillMaxSize().clip(CircleShape).background(bg),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Text(
                                            text = arabicNumber(day),
                                            style = MaterialTheme.typography.labelLarge,
                                            color = fg,
                                            fontWeight = if (isToday || isWhite) FontWeight.Bold else FontWeight.Normal,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(14.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer))
                    Spacer(Modifier.width(8.dp))
                    Text("الأيام البيض (١٣ و١٤ و١٥)", style = MaterialTheme.typography.labelMedium)
                }
            }
        },
    )
}
