package com.example.fadhkuruni

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AdhkarTheme {
                // تخطيط من اليمين إلى اليسار للعربية
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AdhkarApp()
                }
            }
        }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    CHAPTERS("الأبواب", Icons.Filled.MenuBook),
    STATS("السجل", Icons.Filled.CalendarMonth),
    FREE("عداد حر", Icons.Filled.TouchApp),
}

private enum class DhikrStatus { NOT_STARTED, IN_PROGRESS, DONE }

private fun statusOf(done: Int, repeat: Int): DhikrStatus = when {
    done >= repeat -> DhikrStatus.DONE
    done > 0 -> DhikrStatus.IN_PROGRESS
    else -> DhikrStatus.NOT_STARTED
}

/** عدد الأذكار المكتملة في باب معيّن. */
private fun doneItems(counts: Map<String, Int>, chapter: Chapter): Int =
    chapter.items.indices.count { i -> (counts[CounterStore.key(chapter, i)] ?: 0) >= chapter.items[i].repeat }

/** تحويل الأرقام إلى الأرقام العربية (٠١٢...). */
fun arabicNumber(n: Int, minDigits: Int = 1): String =
    n.toString().padStart(minDigits, '0')
        .map { c -> if (c.isDigit()) '٠' + (c - '0') else c }
        .joinToString("")

fun formatTime(hour: Int, minute: Int): String {
    val period = if (hour < 12) "ص" else "م"
    val h12 = if (hour % 12 == 0) 12 else hour % 12
    return "${arabicNumber(h12)}:${arabicNumber(minute, 2)} $period"
}

/** تطبيع النص العربي للبحث: إزالة التشكيل والتطويل وتوحيد الألفات والياء والتاء المربوطة. */
fun normalizeAr(s: String): String = s
    .replace(Regex("[ً-ٰٟـ]"), "")
    .replace('أ', 'ا')
    .replace('إ', 'ا')
    .replace('آ', 'ا')
    .replace('ى', 'ي')
    .replace('ة', 'ه')

private fun dayLabel(cal: Calendar): String =
    SimpleDateFormat("EEEE d MMMM", Locale.forLanguageTag("ar")).format(cal.time)

private fun hijriDateLabel(): String = try {
    SimpleDateFormat("EEEE d MMMM yyyy", Locale.forLanguageTag("ar-SA-u-ca-islamic-umalqura"))
        .format(Date()) + " هـ"
} catch (e: Exception) {
    ""
}

private fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

private fun shareDhikr(context: Context, dhikr: Dhikr, chapterTitle: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "${dhikr.text}\n\n— $chapterTitle")
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة الذكر"))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdhkarApp() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var today by remember { mutableStateOf(CounterStore.today()) }
    val counts = remember {
        mutableStateMapOf<String, Int>().apply { putAll(CounterStore.load(context, CounterStore.today())) }
    }
    var fontSize by remember { mutableFloatStateOf(DisplayPrefs.fontSize(context)) }
    var fontChoice by remember { mutableIntStateOf(DisplayPrefs.fontChoice(context)) }
    var tab by remember { mutableStateOf(Tab.CHAPTERS) }
    var openChapter by remember { mutableStateOf<Chapter?>(null) }
    var lastChapter by remember {
        mutableStateOf(
            AppState.lastChapterId(context)?.let { id -> HISN_CHAPTERS.firstOrNull { it.id == id } }
        )
    }
    var showSettings by remember { mutableStateOf(false) }
    var showResetAll by remember { mutableStateOf(false) }

    // إعادة تحميل العدادات عند العودة إلى التطبيق، لأن اليوم قد يكون تغيّر
    fun reload() {
        today = CounterStore.today()
        counts.clear()
        counts.putAll(CounterStore.load(context, today))
        ProgressWidget.updateAll(context)
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) reload()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val setCount: (String, Int) -> Unit = { key, value ->
        counts[key] = value
        CounterStore.save(context, today, key, value)
        ProgressWidget.updateAll(context)
    }

    // زر الرجوع من الباب يعيدنا إلى القائمة بدل الخروج من التطبيق
    BackHandler(enabled = openChapter != null) { openChapter = null }

    val chapter = openChapter
    Scaffold(
        topBar = {
            if (chapter != null) {
                CenterAlignedTopAppBar(
                    title = {
                        Text(chapter.title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    },
                    navigationIcon = {
                        IconButton(onClick = { openChapter = null }) {
                            Icon(Icons.Filled.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                )
            } else {
                CenterAlignedTopAppBar(
                    title = { Text(tab.label, style = MaterialTheme.typography.titleLarge) },
                    actions = {
                        if (tab == Tab.CHAPTERS) {
                            IconButton(onClick = { showResetAll = true }) {
                                Icon(Icons.Filled.RestartAlt, contentDescription = "إعادة أذكار اليوم")
                            }
                            IconButton(onClick = { showSettings = true }) {
                                Icon(Icons.Filled.Settings, contentDescription = "الإعدادات")
                            }
                        }
                    },
                )
            }
        },
        bottomBar = {
            if (chapter == null) {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label) },
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            if (chapter != null) {
                ChapterScreen(
                    chapter = chapter,
                    counts = counts,
                    fontSize = fontSize,
                    fontFamily = bodyFont(fontChoice),
                    setCount = setCount,
                )
            } else {
                when (tab) {
                    Tab.CHAPTERS -> HomeScreen(
                        counts = counts,
                        lastChapter = lastChapter,
                        onOpen = { c ->
                            AppState.setLastChapterId(context, c.id)
                            lastChapter = c
                            openChapter = c
                        },
                    )
                    Tab.STATS -> StatsScreen()
                    Tab.FREE -> FreeCounterScreen()
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            fontSize = fontSize,
            fontChoice = fontChoice,
            onFontSizeChange = { size ->
                fontSize = size
                DisplayPrefs.setFontSize(context, size)
            },
            onFontChoiceChange = { choice ->
                fontChoice = choice
                DisplayPrefs.setFontChoice(context, choice)
            },
            onDataChanged = { reload() },
            onDismiss = { showSettings = false },
        )
    }

    if (showResetAll) {
        AlertDialog(
            onDismissRequest = { showResetAll = false },
            title = { Text("إعادة أذكار اليوم؟") },
            text = { Text("سيتم تصفير جميع العدادات لليوم الحالي.") },
            confirmButton = {
                TextButton(onClick = {
                    CounterStore.resetDay(context, today)
                    counts.clear()
                    ProgressWidget.updateAll(context)
                    showResetAll = false
                }) { Text("نعم، أعد") }
            },
            dismissButton = { TextButton(onClick = { showResetAll = false }) { Text("إلغاء") } },
        )
    }
}

@Composable
fun HomeScreen(
    counts: Map<String, Int>,
    lastChapter: Chapter?,
    onOpen: (Chapter) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<ChapterGroup?>(null) }

    val needle = normalizeAr(query.trim())
    val visible = HISN_CHAPTERS.filter { ch ->
        (group == null || groupOf(ch.id) == group) &&
            (needle.isEmpty() ||
                normalizeAr(ch.title).contains(needle) ||
                ch.items.any { normalizeAr(it.text).contains(needle) })
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = hijriDateLabel() + "  •  " + dayLabel(Calendar.getInstance()),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("ابحث في الأبواب والأذكار") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Filled.Close, contentDescription = "مسح البحث")
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = group == null,
                onClick = { group = null },
                label = { Text("الكل") },
            )
            ChapterGroup.entries.filter { it != ChapterGroup.OTHER }.forEach { g ->
                FilterChip(
                    selected = group == g,
                    onClick = { group = if (group == g) null else g },
                    label = { Text(g.title) },
                )
            }
        }

        if (lastChapter != null && needle.isEmpty() && group == null) {
            Card(
                onClick = { onOpen(lastChapter) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("متابعة القراءة", style = MaterialTheme.typography.labelMedium)
                    Text(lastChapter.title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (visible.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.Center,
            ) {
                Text("لا توجد نتائج مطابقة", style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                items(visible, key = { it.id }) { chapter ->
                    ChapterTile(
                        chapter = chapter,
                        done = doneItems(counts, chapter),
                        total = chapter.items.size,
                        onClick = { onOpen(chapter) },
                    )
                }
            }
        }
    }
}

@Composable
fun ChapterTile(
    chapter: Chapter,
    done: Int,
    total: Int,
    onClick: () -> Unit,
) {
    val groupColor = Color(groupOf(chapter.id).color)
    val complete = total > 0 && done >= total
    Box(modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Card(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth().height(124.dp),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (complete) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surface,
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    text = chapter.title,
                    style = MaterialTheme.typography.titleSmall,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${arabicNumber(done)} / ${arabicNumber(total)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { if (total == 0) 0f else done.toFloat() / total },
                    modifier = Modifier.fillMaxWidth(0.7f),
                    color = groupColor,
                )
            }
        }
        // رقم الباب بلون مجموعته
        Surface(
            shape = CircleShape,
            color = groupColor,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            Text(
                text = arabicNumber(chapter.id),
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            )
        }
    }
}

@Composable
fun ChapterScreen(
    chapter: Chapter,
    counts: Map<String, Int>,
    fontSize: Float,
    fontFamily: FontFamily,
    setCount: (String, Int) -> Unit,
) {
    val context = LocalContext.current
    val dhikrs = chapter.items
    val done = doneItems(counts, chapter)

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text(
                text = "تم ${arabicNumber(done)} من ${arabicNumber(dhikrs.size)}",
                style = MaterialTheme.typography.labelLarge,
            )
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { if (dhikrs.isEmpty()) 0f else done.toFloat() / dhikrs.size },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            itemsIndexed(dhikrs) { index, dhikr ->
                val key = CounterStore.key(chapter, index)
                val count = counts[key] ?: 0
                DhikrCard(
                    index = index + 1,
                    total = dhikrs.size,
                    dhikr = dhikr,
                    done = count,
                    fontSize = fontSize,
                    fontFamily = fontFamily,
                    onIncrement = { if (count < dhikr.repeat) setCount(key, count + 1) },
                    onDecrement = { if (count > 0) setCount(key, count - 1) },
                    onReset = { setCount(key, 0) },
                    onShare = { shareDhikr(context, dhikr, chapter.title) },
                )
            }
        }
    }
}

@Composable
fun DhikrCard(
    index: Int,
    total: Int,
    dhikr: Dhikr,
    done: Int,
    fontSize: Float,
    fontFamily: FontFamily,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onReset: () -> Unit,
    onShare: () -> Unit,
) {
    val status = statusOf(done, dhikr.repeat)
    val (icon, tint) = when (status) {
        DhikrStatus.DONE -> Icons.Filled.CheckCircle to MaterialTheme.colorScheme.primary
        DhikrStatus.IN_PROGRESS -> Icons.Filled.HourglassTop to MaterialTheme.colorScheme.secondary
        DhikrStatus.NOT_STARTED -> Icons.Outlined.RadioButtonUnchecked to MaterialTheme.colorScheme.onSurfaceVariant
    }
    val statusLabel = when (status) {
        DhikrStatus.DONE -> "تم ✓"
        DhikrStatus.IN_PROGRESS -> "قيد التنفيذ"
        DhikrStatus.NOT_STARTED -> "لم يبدأ بعد"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (status == DhikrStatus.DONE) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "الذكر ${arabicNumber(index)} من ${arabicNumber(total)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = dhikr.text,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontFamily = fontFamily,
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.9f).sp,
                ),
                textAlign = TextAlign.Justify,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(14.dp))
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CounterButton(
                    done = done,
                    repeat = dhikr.repeat,
                    onIncrement = onIncrement,
                    onDecrement = onDecrement,
                )
            }
            if (status != DhikrStatus.DONE) {
                Text(
                    text = "اضغط للعد، واضغط مطولاً للتراجع",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = tint,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onShare) {
                    Icon(Icons.Filled.Share, contentDescription = "مشاركة الذكر")
                }
                IconButton(onClick = onReset) {
                    Icon(Icons.Filled.Refresh, contentDescription = "تصفير هذا الذكر")
                }
            }
        }
    }
}

/** عداد دائري: الضغطة تزيد، والضغط المطوّل ينقص (تراجع). */
@Composable
fun CounterButton(
    done: Int,
    repeat: Int,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val complete = done >= repeat
    val progress = if (repeat <= 0) 0f else (done.toFloat() / repeat).coerceIn(0f, 1f)
    val ringColor = if (complete) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary

    Box(
        modifier = Modifier
            .size(92.dp)
            .pointerInput(done, repeat) {
                detectTapGestures(
                    onTap = {
                        if (done < repeat) {
                            onIncrement()
                            haptic.performHapticFeedback(
                                if (done + 1 >= repeat) HapticFeedbackType.LongPress
                                else HapticFeedbackType.TextHandleMove
                            )
                        }
                    },
                    onLongPress = {
                        if (done > 0) {
                            onDecrement()
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        }
                    },
                )
            }
            .semantics {
                role = Role.Button
                contentDescription = "عداد الذكر: ${arabicNumber(done)} من ${arabicNumber(repeat)}"
            },
        contentAlignment = Alignment.Center,
    ) {
        CircularProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxSize(),
            color = ringColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            strokeWidth = 6.dp,
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = arabicNumber(done),
                style = MaterialTheme.typography.titleLarge,
                color = ringColor,
            )
            Text(
                text = "من ${arabicNumber(repeat)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen() {
    val context = LocalContext.current
    val streak = remember { CounterStore.streak(context) }
    val longest = remember { CounterStore.longestStreak(context) }
    val monthDays = remember { CounterStore.completedThisMonth(context) }
    val todayDone = remember {
        val todayCounts = CounterStore.load(context, CounterStore.today())
        HISN_CHAPTERS.sumOf { doneItems(todayCounts, it) }
    }
    val completed = remember { CounterStore.completedDays(context) }
    val days = remember {
        (0..29).map { offset -> Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) } }
    }
    var detailDay by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("أيام متتالية", arabicNumber(streak), Modifier.weight(1f))
                StatCard("أطول سلسلة", arabicNumber(longest), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("أيام مكتملة هذا الشهر", arabicNumber(monthDays), Modifier.weight(1f))
                StatCard("أذكار اليوم", arabicNumber(todayDone), Modifier.weight(1f))
            }
        }
        item {
            Text(
                text = "آخر 30 يوماً",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
        items(days) { cal ->
            val day = CounterStore.dayKey(cal)
            DayRow(
                day = day,
                cal = cal,
                complete = day in completed,
                onClick = { detailDay = day },
            )
        }
    }

    detailDay?.let { day ->
        DayDetailDialog(day = day, onDismiss = { detailDay = null })
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(value, style = MaterialTheme.typography.headlineSmall)
            Text(label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun DayRow(day: String, cal: Calendar, complete: Boolean, onClick: () -> Unit) {
    val context = LocalContext.current
    val counts = remember(day) { CounterStore.load(context, day) }
    val started = counts.values.any { it > 0 }
    val (icon, tint) = when {
        complete -> Icons.Filled.CheckCircle to MaterialTheme.colorScheme.primary
        started -> Icons.Filled.HourglassTop to MaterialTheme.colorScheme.secondary
        else -> Icons.Outlined.RadioButtonUnchecked to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, contentDescription = null, tint = tint)
            Spacer(Modifier.width(10.dp))
            Text(dayLabel(cal), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun DayDetailDialog(day: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val counts = remember(day) { CounterStore.load(context, day) }
    val started = HISN_CHAPTERS.filter { ch ->
        ch.items.indices.any { (counts[CounterStore.key(ch, it)] ?: 0) > 0 }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(dayLabel(CounterStore.dayCalendar(day)), style = MaterialTheme.typography.titleMedium)
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                if (started.isEmpty()) {
                    Text("لا توجد أذكار مسجّلة في هذا اليوم.", style = MaterialTheme.typography.bodyMedium)
                }
                started.forEach { ch ->
                    val done = doneItems(counts, ch)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(ch.title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Text(
                            text = "${arabicNumber(done)} / ${arabicNumber(ch.items.size)}",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (done >= ch.items.size) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } },
    )
}

@Composable
fun FreeCounterScreen() {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var value by remember { mutableIntStateOf(AppState.freeCounter(context)) }
    var confirmReset by remember { mutableStateOf(false) }

    fun update(newValue: Int) {
        value = newValue
        AppState.setFreeCounter(context, newValue)
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("عدّاد التسبيح الحر", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        Text(
            text = arabicNumber(value),
            style = MaterialTheme.typography.displaySmall.copy(fontSize = 72.sp),
        )
        Spacer(Modifier.height(24.dp))
        Surface(
            onClick = {
                update(value + 1)
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            },
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(200.dp),
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Text("اضغط للعد", style = MaterialTheme.typography.titleLarge)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { if (value > 0) update(value - 1) }) { Text("تراجع") }
            OutlinedButton(onClick = { confirmReset = true }) { Text("تصفير") }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("تصفير العداد؟") },
            confirmButton = {
                TextButton(onClick = {
                    update(0)
                    confirmReset = false
                }) { Text("نعم، صفّر") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("إلغاء") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDialog(
    fontSize: Float,
    fontChoice: Int,
    onFontSizeChange: (Float) -> Unit,
    onFontChoiceChange: (Int) -> Unit,
    onDataChanged: () -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val configs = remember {
        mutableStateListOf<ReminderConfig>().apply { addAll(Reminders.load(context)) }
    }
    var followUp by remember { mutableStateOf(Reminders.isFollowUpEnabled(context)) }
    var editingIndex by remember { mutableStateOf<Int?>(null) }
    var pendingAfterPermission by remember { mutableStateOf<(() -> Unit)?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingAfterPermission
        pendingAfterPermission = null
        if (granted) {
            action?.invoke()
        } else {
            context.toast("لن تصل التذكيرات بدون إذن الإشعارات")
        }
    }

    // عند التفعيل نطلب الإذن أولاً، ولا يُحفظ التفعيل إلا إذا مُنح
    fun withNotificationPermission(enabling: Boolean, action: () -> Unit) {
        if (enabling && !Reminders.hasNotificationPermission(context)) {
            pendingAfterPermission = action
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            action()
        }
    }

    fun setReminderEnabled(index: Int, on: Boolean) {
        withNotificationPermission(on) {
            val updated = configs[index].copy(enabled = on)
            configs[index] = updated
            Reminders.save(context, updated)
        }
    }

    fun setFollowUp(on: Boolean) {
        withNotificationPermission(on) {
            followUp = on
            Reminders.setFollowUpEnabled(context, on)
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(CounterStore.exportJson(context).toByteArray(Charsets.UTF_8))
                }
            }.isSuccess
            context.toast(if (ok) "تم حفظ النسخة الاحتياطية" else "تعذّر حفظ الملف")
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)
                    ?.use { it.readText() }
                    ?: error("empty file")
                CounterStore.importJson(context, text)
            }.onSuccess { count ->
                context.toast("تمت استعادة ${arabicNumber(count)} عداداً")
                onDataChanged()
            }.onFailure {
                context.toast("الملف غير صالح")
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الإعدادات", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("التذكيرات", style = MaterialTheme.typography.titleMedium)
                configs.forEachIndexed { index, config ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(config.kind.title, style = MaterialTheme.typography.bodyLarge)
                            TextButton(
                                onClick = { editingIndex = index },
                                contentPadding = PaddingValues(0.dp),
                            ) {
                                Text("الوقت: ${formatTime(config.hour, config.minute)}")
                            }
                        }
                        Switch(
                            checked = config.enabled,
                            onCheckedChange = { on -> setReminderEnabled(index, on) },
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("متابعة أذكار الصباح", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "تذكير بعد ساعة ونصف إن لم تكتمل",
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                    Switch(checked = followUp, onCheckedChange = { on -> setFollowUp(on) })
                }

                HorizontalDivider()

                Text("حجم الخط", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "بسم الله الرحمن الرحيم",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontFamily = bodyFont(fontChoice),
                        fontSize = fontSize.sp,
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
                Slider(
                    value = fontSize,
                    onValueChange = onFontSizeChange,
                    valueRange = 16f..30f,
                    steps = 6,
                )

                Text("نوع الخط", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = fontChoice == 0,
                        onClick = { onFontChoiceChange(0) },
                        label = { Text("قمرة") },
                    )
                    FilterChip(
                        selected = fontChoice == 1,
                        onClick = { onFontChoiceChange(1) },
                        label = { Text("النظام") },
                    )
                }

                HorizontalDivider()

                Text("النسخ الاحتياطي", style = MaterialTheme.typography.titleMedium)
                Text(
                    "يحفظ العدادات في ملف JSON، ويمكن استعادته لاحقاً.",
                    style = MaterialTheme.typography.labelMedium,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { exportLauncher.launch("adhkar-backup.json") }) {
                        Text("تصدير")
                    }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) }) {
                        Text("استعادة")
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("تم") } },
    )

    editingIndex?.let { index ->
        val config = configs[index]
        TimePickerDialog(
            initialHour = config.hour,
            initialMinute = config.minute,
            onConfirm = { hour, minute ->
                val updated = config.copy(hour = hour, minute = minute)
                configs[index] = updated
                Reminders.save(context, updated)
                editingIndex = null
            },
            onDismiss = { editingIndex = null },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerDialog(
    initialHour: Int,
    initialMinute: Int,
    onConfirm: (Int, Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val state = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = false,
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onConfirm(state.hour, state.minute) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        text = { TimePicker(state = state) },
    )
}
