package com.example.fadhkuruni

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AdhkarTheme {
                // تخطيط من اليمين إلى اليسار للعربية
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AdhkarScreen()
                }
            }
        }
    }
}

/** الفئات الثلاث الظاهرة مباشرة في شريط التنقل السفلي. */
private val mainCategories = listOf(Category.MORNING, Category.EVENING, Category.SLEEP)

private fun Category.icon(): ImageVector = when (this) {
    Category.MORNING -> Icons.Filled.WbSunny
    Category.EVENING -> Icons.Filled.WbTwilight
    Category.AFTER_PRAYER -> Icons.Filled.Star
    Category.SLEEP -> Icons.Filled.Bedtime
    Category.WAKING -> Icons.Filled.Alarm
    Category.LEAVING_HOME -> Icons.Filled.DirectionsWalk
    Category.EATING -> Icons.Filled.Restaurant
    Category.ISTIGHFAR -> Icons.Filled.VolunteerActivism
}

private fun Category.shortLabel(): String = when (this) {
    Category.MORNING -> "الصباح"
    Category.EVENING -> "المساء"
    Category.AFTER_PRAYER -> "بعد الصلاة"
    Category.SLEEP -> "النوم"
    Category.WAKING -> "الاستيقاظ"
    Category.LEAVING_HOME -> "الخروج"
    Category.EATING -> "الطعام"
    Category.ISTIGHFAR -> "الاستغفار"
}

/** التبويب المناسب للوقت الحالي عند فتح التطبيق. */
private fun categoryForNow(): Category =
    when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 4..11 -> Category.MORNING
        in 12..15 -> Category.AFTER_PRAYER
        in 16..21 -> Category.EVENING
        else -> Category.SLEEP
    }

private enum class DhikrStatus { NOT_STARTED, IN_PROGRESS, DONE }

private fun statusOf(done: Int, repeat: Int): DhikrStatus = when {
    done >= repeat -> DhikrStatus.DONE
    done > 0 -> DhikrStatus.IN_PROGRESS
    else -> DhikrStatus.NOT_STARTED
}

/** تحويل الأرقام إلى الأرقام العربية (٠١٢...). */
fun arabicNumber(n: Int, minDigits: Int = 1): String =
    n.toString().padStart(minDigits, '0')
        .map { c -> if (c.isDigit()) '٠' + (c - '0') else c }
        .joinToString("")

fun formatTime(hour: Int, minute: Int): String {
    val period = if (hour < 12) "ص" else "م"
    val h12 = if (hour % 12 == 0) 12 else hour % 12
    return "${arabicNumber(h12)}:${arabicNumber(minute, 2)} $period"
}

private fun dayLabel(cal: Calendar): String =
    SimpleDateFormat("EEEE d MMMM", Locale.forLanguageTag("ar")).format(cal.time)

private fun shareDhikr(context: Context, dhikr: Dhikr, categoryTitle: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "${dhikr.text}\n\n— $categoryTitle")
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة الذكر"))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdhkarScreen() {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val today = CounterStore.today()

    var selected by remember { mutableStateOf(categoryForNow()) }
    val counts = remember {
        mutableStateMapOf<String, Int>().apply { putAll(CounterStore.load(context, today)) }
    }
    var fontSize by remember { mutableStateOf(DisplayPrefs.fontSize(context)) }

    var showMore by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showResetAll by remember { mutableStateOf(false) }

    val setCount: (String, Int) -> Unit = { key, value ->
        counts[key] = value
        CounterStore.save(context, today, key, value)
    }

    val dhikrs = selected.items
    val doneCount = dhikrs.indices.count { i ->
        (counts["${selected.name}-$i"] ?: 0) >= dhikrs[i].repeat
    }
    val moreCategories = Category.entries.filter { it !in mainCategories }
    val inMore = selected !in mainCategories

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("فاذكروني أذكركم", style = MaterialTheme.typography.titleLarge) },
                actions = {
                    IconButton(onClick = { showHistory = true }) {
                        Icon(Icons.Filled.CalendarMonth, contentDescription = "السجل")
                    }
                    IconButton(onClick = { showResetAll = true }) {
                        Icon(Icons.Filled.RestartAlt, contentDescription = "إعادة أذكار اليوم")
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Filled.Settings, contentDescription = "الإعدادات")
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                mainCategories.forEach { c ->
                    NavigationBarItem(
                        selected = selected == c,
                        onClick = { selected = c },
                        icon = { Icon(c.icon(), contentDescription = null) },
                        label = { Text(c.shortLabel()) },
                    )
                }
                NavigationBarItem(
                    selected = inMore,
                    onClick = { showMore = true },
                    icon = { Icon(Icons.Filled.MoreHoriz, contentDescription = null) },
                    label = { Text("المزيد") },
                )
            }
        },
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text(selected.title, style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "تم ${arabicNumber(doneCount)} من ${arabicNumber(dhikrs.size)}",
                    style = MaterialTheme.typography.labelLarge,
                )
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { if (dhikrs.isEmpty()) 0f else doneCount.toFloat() / dhikrs.size },
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                itemsIndexed(dhikrs) { index, dhikr ->
                    val key = "${selected.name}-$index"
                    val done = counts[key] ?: 0
                    DhikrCard(
                        dhikr = dhikr,
                        done = done,
                        fontSize = fontSize,
                        onTap = {
                            if (done < dhikr.repeat) {
                                val next = done + 1
                                setCount(key, next)
                                haptic.performHapticFeedback(
                                    if (next >= dhikr.repeat) HapticFeedbackType.LongPress
                                    else HapticFeedbackType.TextHandleMove
                                )
                            }
                        },
                        onReset = { setCount(key, 0) },
                        onShare = { shareDhikr(context, dhikr, selected.title) },
                    )
                }
            }
        }
    }

    if (showMore) {
        ModalBottomSheet(onDismissRequest = { showMore = false }) {
            Text(
                "أذكار أخرى",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            )
            moreCategories.forEach { c ->
                ListItem(
                    headlineContent = { Text(c.title) },
                    leadingContent = { Icon(c.icon(), contentDescription = null) },
                    modifier = Modifier.clickable {
                        selected = c
                        showMore = false
                    },
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showSettings) {
        SettingsDialog(
            fontSize = fontSize,
            onFontSizeChange = { size ->
                fontSize = size
                DisplayPrefs.setFontSize(context, size)
            },
            onDismiss = { showSettings = false },
        )
    }

    if (showHistory) {
        HistoryDialog(onDismiss = { showHistory = false })
    }

    if (showResetAll) {
        AlertDialog(
            onDismissRequest = { showResetAll = false },
            title = { Text("إعادة أذكار اليوم؟") },
            text = { Text("سيتم تصفير جميع العدادات لليوم الحالي.") },
            confirmButton = {
                TextButton(onClick = {
                    CounterStore.resetDay(context, today)
                    counts.clear()
                    showResetAll = false
                }) { Text("نعم، أعد") }
            },
            dismissButton = { TextButton(onClick = { showResetAll = false }) { Text("إلغاء") } },
        )
    }
}

@Composable
fun DhikrCard(
    dhikr: Dhikr,
    done: Int,
    fontSize: Float,
    onTap: () -> Unit,
    onReset: () -> Unit,
    onShare: () -> Unit,
) {
    val status = statusOf(done, dhikr.repeat)
    val (icon, tint) = when (status) {
        DhikrStatus.DONE -> Icons.Filled.CheckCircle to MaterialTheme.colorScheme.primary
        DhikrStatus.IN_PROGRESS -> Icons.Filled.HourglassTop to MaterialTheme.colorScheme.secondary
        DhikrStatus.NOT_STARTED -> Icons.Outlined.RadioButtonUnchecked to MaterialTheme.colorScheme.onSurfaceVariant
    }
    val statusLabel = when (status) {
        DhikrStatus.DONE -> "تم ✓ (${arabicNumber(done)} / ${arabicNumber(dhikr.repeat)})"
        DhikrStatus.IN_PROGRESS -> "${arabicNumber(done)} / ${arabicNumber(dhikr.repeat)}"
        DhikrStatus.NOT_STARTED -> "لم يبدأ بعد"
    }

    Card(
        onClick = { if (status != DhikrStatus.DONE) onTap() },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (status == DhikrStatus.DONE) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = tint,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onShare) {
                    Icon(Icons.Filled.Share, contentDescription = "مشاركة")
                }
                IconButton(onClick = onReset) {
                    Icon(Icons.Filled.Refresh, contentDescription = "إعادة")
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = dhikr.text,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.9f).sp,
                ),
                textAlign = TextAlign.Justify,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { done.toFloat() / dhikr.repeat },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
fun SettingsDialog(
    fontSize: Float,
    onFontSizeChange: (Float) -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val configs = remember {
        mutableStateListOf<ReminderConfig>().apply { addAll(Reminders.load(context)) }
    }
    var editingIndex by remember { mutableStateOf<Int?>(null) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* إن رُفض الإذن فلن تظهر الإشعارات */ }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الإعدادات", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("التذكيرات", style = MaterialTheme.typography.titleMedium)
                configs.forEachIndexed { index, config ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(config.category.title, style = MaterialTheme.typography.bodyLarge)
                            TextButton(
                                onClick = { editingIndex = index },
                                contentPadding = PaddingValues(0.dp),
                            ) {
                                Text("الوقت: ${formatTime(config.hour, config.minute)}")
                            }
                        }
                        Switch(
                            checked = config.enabled,
                            onCheckedChange = { on ->
                                if (on && Build.VERSION.SDK_INT >= 33) {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                val updated = config.copy(enabled = on)
                                configs[index] = updated
                                Reminders.save(context, updated)
                            },
                        )
                    }
                }

                HorizontalDivider()

                Text("حجم الخط", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "بسم الله الرحمن الرحيم",
                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = fontSize.sp),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
                Slider(
                    value = fontSize,
                    onValueChange = onFontSizeChange,
                    valueRange = 16f..30f,
                    steps = 6,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("تم") } },
    )

    editingIndex?.let { index ->
        val config = configs[index]
        TimePickerDialog(
            initialHour = config.hour,
            initialMinute = config.minute,
            onConfirm = { hour, minute ->
                val updated = config.copy(hour = hour, minute = minute)
                configs[index] = updated
                Reminders.save(context, updated)
                editingIndex = null
            },
            onDismiss = { editingIndex = null },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerDialog(
    initialHour: Int,
    initialMinute: Int,
    onConfirm: (Int, Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val state = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = false,
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onConfirm(state.hour, state.minute) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
        text = { TimePicker(state = state) },
    )
}

@Composable
fun HistoryDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val streak = remember { CounterStore.streak(context) }
    val days = remember {
        (0..13).map { offset -> Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) } }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("السجل", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "أيام متتالية مكتملة: ${arabicNumber(streak)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    "اليوم المكتمل: أذكار الصباح والمساء كاملة",
                    style = MaterialTheme.typography.labelMedium,
                )
                Spacer(Modifier.height(12.dp))
                days.forEach { cal ->
                    val day = CounterStore.dayKey(cal)
                    val counts = CounterStore.load(context, day)
                    val complete = CounterStore.isDayComplete(context, day)
                    val started = counts.values.any { it > 0 }
                    val (icon, tint) = when {
                        complete -> Icons.Filled.CheckCircle to MaterialTheme.colorScheme.primary
                        started -> Icons.Filled.HourglassTop to MaterialTheme.colorScheme.secondary
                        else -> Icons.Outlined.RadioButtonUnchecked to MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(icon, contentDescription = null, tint = tint)
                        Spacer(Modifier.width(10.dp))
                        Text(dayLabel(cal), style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } },
    )
}
