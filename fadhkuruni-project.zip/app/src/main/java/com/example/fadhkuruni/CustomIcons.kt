package com.example.fadhkuruni

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

/** أيقونات مخصّصة لا توجد في المجموعة الأساسية. */
object CustomIcons {
    /** مسجد: قبة ومئذنتان، بدل الشكل السابق. */
    val Mosque: ImageVector by lazy {
        ImageVector.Builder(
            name = "Mosque",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).path(fill = SolidColor(Color.Black)) {
            // القبة
            moveTo(4f, 21f)
            lineTo(4f, 14f)
            curveTo(4f, 8.5f, 7.5f, 5.5f, 12f, 5.5f)
            curveTo(16.5f, 5.5f, 20f, 8.5f, 20f, 14f)
            lineTo(20f, 21f)
            close()
            // الهلال فوق القبة
            moveTo(11.25f, 5.5f)
            lineTo(12.75f, 5.5f)
            lineTo(12.75f, 2.5f)
            lineTo(11.25f, 2.5f)
            close()
            // المئذنة اليمنى
            moveTo(1f, 21f)
            lineTo(1f, 9f)
            lineTo(2.25f, 6f)
            lineTo(3.5f, 9f)
            lineTo(3.5f, 21f)
            close()
            // المئذنة اليسرى
            moveTo(20.5f, 21f)
            lineTo(20.5f, 9f)
            lineTo(21.75f, 6f)
            lineTo(23f, 9f)
            lineTo(23f, 21f)
            close()
        }.build()
    }
}
