package com.example.fadhkuruni

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/** أيقونات مخصّصة لا توجد في المجموعة الأساسية. */
object CustomIcons {
    /** مسجد: قبة ومئذنتان. */
    val Mosque: ImageVector by lazy {
        ImageVector.Builder(
            name = "Mosque",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).addPath(
            pathData = addPathNodes(
                "M4 21 L4 14 C4 8.5 7.5 5.5 12 5.5 C16.5 5.5 20 8.5 20 14 L20 21 Z " +
                    "M11.25 5.5 L12.75 5.5 L12.75 2.5 L11.25 2.5 Z " +
                    "M1 21 L1 9 L2.25 6 L3.5 9 L3.5 21 Z " +
                    "M20.5 21 L20.5 9 L21.75 6 L23 9 L23 21 Z"
            ),
            fill = SolidColor(Color.Black),
        ).build()
    }

    /** شاهد قبر، للجنائز والقبور. */
    val Tombstone: ImageVector by lazy {
        ImageVector.Builder(
            name = "Tombstone",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).addPath(
            pathData = addPathNodes(
                "M6 21 L6 9 C6 5.7 8.7 3 12 3 C15.3 3 18 5.7 18 9 L18 21 Z " +
                    "M3 21.5 L21 21.5 L21 23.5 L3 23.5 Z"
            ),
            fill = SolidColor(Color.Black),
        ).build()
    }

    /** الكعبة: مكعب بنطاق في الوسط، ويُرسم الشريط كفراغ. */
    val Kaaba: ImageVector by lazy {
        ImageVector.Builder(
            name = "Kaaba",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).addPath(
            pathData = addPathNodes(
                "M3 4 L21 4 L21 20 L3 20 Z M3 8 L21 8 L21 10.5 L3 10.5 Z"
            ),
            pathFillType = PathFillType.EvenOdd,
            fill = SolidColor(Color.Black),
        ).build()
    }
}
