package com.example.fadhkuruni

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/** أيقونات مخصّصة لا توجد في المجموعة الأساسية. */
object CustomIcons {
    /** مسجد: قبة ومئذنتان، ومرسوم بمسار SVG. */
    val Mosque: ImageVector by lazy {
        ImageVector.Builder(
            name = "Mosque",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).addPath(
            pathData = addPathNodes(
                "M4 21 L4 14 C4 8.5 7.5 5.5 12 5.5 C16.5 5.5 20 8.5 20 14 L20 21 Z " +
                    "M11.25 5.5 L12.75 5.5 L12.75 2.5 L11.25 2.5 Z " +
                    "M1 21 L1 9 L2.25 6 L3.5 9 L3.5 21 Z " +
                    "M20.5 21 L20.5 9 L21.75 6 L23 9 L23 21 Z"
            ),
            fill = SolidColor(Color.Black),
        ).build()
    }
}
