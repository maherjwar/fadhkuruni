package com.example.fadhkuruni

import android.content.Context
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/** خط قمرة للنصوص، وخط غروب للعناوين. */
val Qomra = FontFamily(
    Font(R.font.qomra_regular, FontWeight.Normal),
    Font(R.font.qomra_medium, FontWeight.Medium),
    Font(R.font.qomra_bold, FontWeight.Bold),
)

private val Ghroob = FontFamily(
    Font(R.font.ghroob_bold, FontWeight.Bold),
)

private val baseTypography = Typography()

private val AppTypography = Typography(
    displaySmall = baseTypography.displaySmall.copy(fontFamily = Qomra),
    headlineSmall = baseTypography.headlineSmall.copy(fontFamily = Ghroob),
    titleLarge = baseTypography.titleLarge.copy(fontFamily = Ghroob),
    titleMedium = baseTypography.titleMedium.copy(fontFamily = Qomra, fontWeight = FontWeight.Bold),
    titleSmall = baseTypography.titleSmall.copy(fontFamily = Qomra),
    bodyLarge = baseTypography.bodyLarge.copy(fontFamily = Qomra),
    bodyMedium = baseTypography.bodyMedium.copy(fontFamily = Qomra),
    bodySmall = baseTypography.bodySmall.copy(fontFamily = Qomra),
    labelLarge = baseTypography.labelLarge.copy(fontFamily = Qomra),
    labelMedium = baseTypography.labelMedium.copy(fontFamily = Qomra),
    labelSmall = baseTypography.labelSmall.copy(fontFamily = Qomra),
)

/** ألوان الوضع الفاتح مستمدة من الأيقونة: أخضر الأيقونة، وذهبي الإطار، وكريمي الخلفية. */
private val LightColors = lightColorScheme(
    primary = Color(0xFF2F7D4F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD3EBD6),
    onPrimaryContainer = Color(0xFF0E2E1A),
    secondary = Color(0xFFB8965A),
    secondaryContainer = Color(0xFFF2E6C8),
    onSecondaryContainer = Color(0xFF3B2E12),
    background = Color(0xFFF6F0E3),
    surface = Color(0xFFFFFBF3),
    surfaceVariant = Color(0xFFEDE5D2),
    onSurface = Color(0xFF1F1D18),
    onSurfaceVariant = Color(0xFF4C4A40),
    outlineVariant = Color(0xFFD9CFB8),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FD6B6),
    onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF1B5140),
    onPrimaryContainer = Color(0xFFCDEBDD),
    secondary = Color(0xFFE0C27A),
    secondaryContainer = Color(0xFF4A3D1E),
    background = Color(0xFF111412),
    surface = Color(0xFF181C1A),
    surfaceVariant = Color(0xFF262B28),
    onSurface = Color(0xFFE3E3DE),
    onSurfaceVariant = Color(0xFFC3C8C2),
)

@Composable
fun AdhkarTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}

/** خط النص المختار من الإعدادات: 0 = قمرة، 1 = خط النظام. */
fun bodyFont(choice: Int): FontFamily = if (choice == 1) FontFamily.Default else Qomra

/** الوضع الليلي أو الفاتح، ويتبع النظام عند أول تشغيل ثم يحفظ اختيار المستخدم. */
object ThemePrefs {
    private const val PREFS = "settings"
    private const val KEY = "dark_mode"

    fun isDark(context: Context, systemDefault: Boolean): Boolean {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return if (p.contains(KEY)) p.getBoolean(KEY, false) else systemDefault
    }

    fun setDark(context: Context, dark: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, dark).apply()
    }
}
